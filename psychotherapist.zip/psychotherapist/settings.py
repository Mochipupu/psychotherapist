﻿"""
Django settings for psychotherapist project.

Based on 'django-admin startproject' using Django 2.1.2.

For more information on this file, see
https://docs.djangoproject.com/en/2.1/topics/settings/

For the full list of settings and their values, see
https://docs.djangoproject.com/en/2.1/ref/settings/
"""

import os
import posixpath
from handler.handler_enum import *

# Build paths inside the project like this: os.path.join(BASE_DIR, ...)
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# Quick-start development settings - unsuitable for production
# See https://docs.djangoproject.com/en/2.1/howto/deployment/checklist/

# SECURITY WARNING: keep the secret key used in production secret!
SECRET_KEY = 'd128691c-056c-4c03-ba69-2c0025ff501e'

# SECURITY WARNING: don't run with debug turned on in production!
DEBUG = True

ALLOWED_HOSTS = ['*']

# Application references
# https://docs.djangoproject.com/en/2.1/ref/settings/#std:setting-INSTALLED_APPS
INSTALLED_APPS = [
    'app',
    # Add your apps here to enable them
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
]

# Middleware framework
# https://docs.djangoproject.com/en/2.1/topics/http/middleware/
MIDDLEWARE = [
    'django.middleware.security.SecurityMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
]

ROOT_URLCONF = 'psychotherapist.urls'

# Template configuration
# https://docs.djangoproject.com/en/2.1/topics/templates/
TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [],
        'APP_DIRS': True,
        'OPTIONS': {
            'context_processors': [
                'django.template.context_processors.debug',
                'django.template.context_processors.request',
                'django.contrib.auth.context_processors.auth',
                'django.contrib.messages.context_processors.messages',
            ],
        },
    },
]

WSGI_APPLICATION = 'psychotherapist.wsgi.application'
# Database
# https://docs.djangoproject.com/en/2.1/ref/settings/#databases
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.sqlite3',
        'NAME': os.path.join(BASE_DIR, 'db.sqlite3'),
    }
}

# Password validation
# https://docs.djangoproject.com/en/2.1/ref/settings/#auth-password-validators
AUTH_PASSWORD_VALIDATORS = [
    {
        'NAME': 'django.contrib.auth.password_validation.UserAttributeSimilarityValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.MinimumLengthValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.CommonPasswordValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.NumericPasswordValidator',
    },
]

# Internationalization
# https://docs.djangoproject.com/en/2.1/topics/i18n/
LANGUAGE_CODE = 'en-us'
TIME_ZONE = 'UTC'
USE_I18N = True
USE_L10N = True
USE_TZ = True

# Static files (CSS, JavaScript, Images)
# https://docs.djangoproject.com/en/2.1/howto/static-files/
STATIC_URL = '/static/'
STATIC_ROOT = posixpath.join(*(BASE_DIR.split(os.path.sep) + ['static']))

# ================== 以上為系統預設，不要修改。僅可修改以下部分 ==============================

SQL_CONNECTION_INFO = { "home": { "server": "localhost",
                                  "database": "Psychotherapy",
                                  "user": "sa",
                                  "password": "as",
                                  #"password": "Nancyqqpan680718",
                                 },
                      }
'''MS-SQL資料庫連線字串'''

FRONT_FUNCTIONS = [
    { "fid": 1, "ParentID": 0, "Item": "簡式健康量表", "Sort": 1, "TypeCode": "C001", "Visible": 1, "IsAdmin": 0, "Url": "/BSRS.html", "Icon": "fas fa-edit" },
    { "fid": 2, "ParentID": 0, "Item": "台灣人憂鬱症量表", "Sort": 2, "TypeCode": "C100", "Visible": 1, "IsAdmin": 0, "Url": "/depression.html", "Icon": "fas fa-tools" },
    { "fid": 3, "ParentID": 0, "Item": "跟我聊聊", "Sort": 3, "TypeCode": "C200", "Visible": 1, "IsAdmin": 0, "Url": "/chat.html", "Icon": "far fa-frown-open" },
    { "fid": 4, "ParentID": 0, "Item": "諮商師媒合", "Sort": 4, "TypeCode": "C300", "Visible": 0, "IsAdmin": 0, "Url": "/matchmaking.html", "Icon": "far fa-frown-open" },
]
'''前端選單功能清單'''

DEFAULT_LIST_ROW_COUNT = 10
'''get_paged_list_dicts() 分頁顯示最多的資料列數'''

DATE_FORMATS = ['%y/%m/%d %H:%M:%S', '%Y-%m-%d %H:%M:%S', '%Y-%m-%d %H:%M:%S.%f', '%Y-%m-%d']
'''日期文字轉換成 日期 時，需要提供給python的『轉換形式』'''

REGULAR_EXPRESS_SYMBOLS = r'"|\s|\`|\~|\!|\@|\#|\$|\%|\^|\&|\*|\(|\)|\-|\=|\+|\[|\]|\{|\}|\:|\;|\,|\.|\?|\<|\>'
'''檔案名稱、Excel(csv)欄位名稱不能包含的字元(其實為MS-SQL不能設定為Table、屬性的字元限制)'''

REGULAR_EXPRESS_CHINESE = r'[\u4e00-\u9fff]+'
'''中文字元檢查。限制檔案名稱、欄位名稱不能為中文，避免後續程式碼有誤'''

KEEP_ALIVE = "<script>$(function () { setInterval('KeepSessionAlive()', 10000); });</script>"

GOOGLE_API_KEY = ""