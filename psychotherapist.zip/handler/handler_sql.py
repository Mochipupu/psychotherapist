﻿from enum import IntEnum
from datetime import datetime
from decimal import Decimal
import time

from django.conf import settings
import pymssql
from sqlalchemy import create_engine, text
import numpy as np
import pandas as pd 

from .utils import *


class server_name(IntEnum):
    home = 0
    IPG = 1
    A1MES = 2
    DIEBANK = 3
    

class handler_sql:
    """
    A class for retrieving data from MS-SQL servers.
    """
    def __init__(self, server: server_name) -> None:
        """
        A constructor with one parameter.

        [Parameters]
        server: an enum item in 'IntEnum server_name'

        [Returns]
        None
        """
        if (server.name not in settings.SQL_CONNECTION_INFO.keys()):
            raise Exception("無法找到伺服器資訊")
        self.connection_info = settings.SQL_CONNECTION_INFO[server.name]
        
    def set_server_connection_profile(self, sql_connect_info) -> None:
        """
        Set the connection profiles of SQL servers

        [Parameters]
        sql_connect_info: a list of dict. A dict looks like 
        { "FMC": {
              "server": "FMC4FDB01\FMC4FCIM",
              "database": "cmNavigo",
              "user": "xxx",
              "password": "yyy",
              }
        }

        [Returns]
        None
        """
        self.sql_connect_info = sql_connect_info

    def _get_connection(self) -> object:
        """
        An internal function for getting the connection object for a server

        [Parameters]
        None

        [Returns]
        A connection object
        """
        try:
            connect_info = self.connection_info
            conn = pymssql.connect(server = connect_info["server"],
                                   user = connect_info["user"],
                                   password = connect_info["password"],
                                   database = connect_info["database"],
                                   tds_version = '7.2')
            return conn
        except Exception as e:
            print(e) #, e.args
            raise Exception(e)

    def get_data_count(self, sql:str, params:tuple = None) -> int:
        
        """
        Get row count of a list of data by a given sql string and its parameters

        [Parameters]
        sql: the sql string
        params: the parameters for the sql string in the type of a tuple

        [Returns]
        A list of tuples, where the first row is the column names
        """
        
        data_count = -1
        try:
            conn = self._get_connection()
            with conn.cursor() as cursor:
                if (params is None):
                    cursor.execute(sql) # cursor.execute in pymssql accepts params to be None
                else:
                    cursor.execute(sql, params) # cursor.execute in pymssql accepts params to be None
                list_data = cursor.fetchall()
                data_count = len(list_data)
            conn.close()
        except Exception as e:
            print(e) #, e.args
            raise Exception(e)

        return data_count

    def get_list_data(self, sql:str, params:tuple = None) -> list:
        """
        Get a list of data by a given sql string and its parameters

        [Parameters]
        sql: the sql string
        params: the parameters for the sql string in the type of a tuple

        [Returns]
        A list of tuples, where the first row is the column names
        """

        list_data = []
        try:
            conn = self._get_connection()
            with conn.cursor() as cursor:
                if (params is None):
                    cursor.execute(sql) # cursor.execute in pymssql accepts params to be None
                else:
                    cursor.execute(sql, params) # cursor.execute in pymssql accepts params to be None
                list_data = cursor.fetchall()
                list_col_names = [desc[0] for desc in cursor.description]
                list_data.insert(0, tuple(list_col_names))
            conn.close()
        except Exception as e:
            print(e) #, e.args
            raise Exception(e)

        return list_data
    
    def get_list_dicts(self, sql: str, params: tuple = None) -> list:
        """
        Get a list of dict by a given sql string and its parameters

        [Parameters]
        sql: the sql string
        params: the parameters for the sql string in the type of a tuple

        [Returns]
        A list of dictionaries, where key names are column names
        """

        list_dicts = []
        try:
            list_data = self.get_list_data(sql, params)
            if (len(list_data) <= 1):
                return list_dicts
        except Exception as e:
            print(e) #, e.args
            raise Exception(e)

        column_names = list_data[0]

        for row_index in range(1, len(list_data)):
            d = {}
            for i in range(len(column_names)):
                obj = list_data[row_index][i]
                if isinstance(obj, Decimal):
                    d[column_names[i]] = float(obj)
                elif isinstance(obj, str):
                    d[column_names[i]] = obj.strip()
                elif isinstance(obj, datetime):
                    d[column_names[i]] = obj.strftime('%Y-%m-%d %H:%M:%S')
                else:
                    d[column_names[i]] = obj

            list_dicts.append(d)

        return list_dicts

    def get_paged_list_dicts(self, page_index: int, table_name: str, list_keywords: list=[], list_col_names: list=[], 
                             orderKey: str = "", additional_condition: str = "", page_row_size: int = None):
        """
        Get paged data

        [Parameters]
        page_index: the requested page index
        table_name: SQL table name

        [Optional parameters]
        list_keywords: keywords for list_col_names
        list_col_names: the column names definded in table_name for searching for target data
        orderKey: order the data by this column name
        additional_condition: Some other conditions, such as IsActive or IsVisible that are not in the keywords

        [Returns]
        A list of dictionaries, where key names are column names
        """
        if (page_row_size is None):
            page_row_size = settings.DEFAULT_LIST_ROW_COUNT

        if (len(orderKey.strip()) == 0):
            orderKey = "fid"

        Sql = "FROM {0}".format(table_name)
        params = None
        if (len(list_keywords) > 0):
            params, lterial = (), []
            for i in range(len(list_keywords)):
                for propertyName in list_col_names:
                    lterial.append("{0} LIKE %s".format(propertyName, i))
                    params += (list_keywords[i],)

            Sql = "FROM {0} WHERE ({1})".format(table_name, " OR ".join(lterial))
            if (additional_condition.Length > 0):
                Sql += (" AND (" + additional_condition + ")")
        else:
            if (len(additional_condition) > 0):
                Sql += (" WHERE " + additional_condition);

        Sql1 = "SELECT * FROM (SELECT ROW_NUMBER() OVER(ORDER BY {0}) AS RowNum, * {1}) as temp ".format(orderKey, Sql) + \
                "WHERE RowNum BETWEEN {0} AND {1}".format((page_index - 1) * page_row_size + 1, page_index * page_row_size)

        return self.get_list_dicts(Sql1, params), self.get_data_count("SELECT * " + Sql, params)
    
    def get_list_instances(self, sql: str, params: tuple = None, class_name: str = "Items") -> list:
        """
        Get a list of class instances by a given sql string and its parameters

        [Parameters]
        sql: the sql string
        params: the parameters for the sql string in the type of a tuple
        class_name: the class name for the instances

        [Returns]
        A list of tuples, where the first row is the column names
        """

        list_instances = []
        try:
            list_data = self.get_list_data(sql, params)
            if (len(list_data) <= 1):
                return list_instances
        except Exception as e:
            print(e) #, e.args
            raise Exception(e)

        tp_column_names = list_data[0]

        for row_index in range(1, len(list_data)):
            klass = globals()[class_name]
            instance = klass()

            for i in range(len(tp_column_names)):
                setattr(instance, tp_column_names[i], list_data[row_index][i])

            list_instances.append(instance)

        return list_instances
    
    def exe_dml(self, sql: str, params:tuple = None) -> int:
        """
        Executing 'Insert', 'Update', and 'Delete' actions in a 'TRANSACTION' way.

        [Parameters]
        sql: looks like "INSERT INTO Table (ROW0, ROW1, ROW2) VALUES(%s, %s, %s)"
        params: the parameters for the sql string in the form of a tuple

        [Returns]
        True if TRANSACTION commit successfully else throwing an exception.
        """
        uid = 0
        try:
            conn = self._get_connection()
            with conn.cursor() as cursor:
                cursor.execute(sql, params)
                if "INSERT" in sql.upper():
                    uid = int(cursor.lastrowid)
                conn.commit()
            conn.close()
            #print(str(uid))
        except Exception as e:
            print(e) #, e.args
            raise Exception(e)
        return uid

    def transcation(self, list_sql: list, list_params: list = None) -> int:
        """
        Executing 'Insert', 'Update', and 'Delete' actions in a 'TRANSACTION' way.

        [Parameters]
        sql: looks like "INSERT INTO Table (ROW0, ROW1, ROW2) VALUES(%s, %s, %s)"
        params: the parameters for the sql string in the form of a tuple

        [Returns]
        True if TRANSACTION commit successfully else throwing an exception.
        """
        try:
            quotient = len(list_sql) / 1000
            to_ = int(quotient) if quotient.is_integer() else (int(quotient) + 1)
            conn = self._get_connection()
            #conn.autocommit = False
            with conn.cursor() as cursor:
                for index in range(to_):
                    list_sub_sql = list_sql[index * 1000: (index + 1) * 1000]
                    list_sub_params = None if (not list_params) else list_params[index * 1000: (index + 1) * 1000]
                    for i in range(len(list_sub_sql)):
                        cursor.execute(list_sub_sql[i], None if (not list_params) else list_sub_params[i])
                    conn.commit()
            conn.close()
        except Exception as e:
            print(e) #, e.args
            raise Exception(e)

    def insert_update_dict(self, d: dict, table_name: str) -> dict:
        """
        透過dict傳遞，以key為欄位名稱、value為值，寫入或更新名為 table_name的資料表
        [Parameters]
        d: 傳入的dict
        table_name: 寫入或更新名為 table_name的資料表

        [Returns]
        將傳入的d於更新fid後回傳
        """
        isInsert = d["fid"] == 0
        sql, paras = "", ()
        fid = d.pop('fid', None) # 先把fid pop取出，d則無fid
        if isInsert:
            sql = "INSERT INTO {0} ({1}) VALUES ({2})".format(table_name, ", ".join(list(d.keys())), ", ".join(["%s"] * len(d.values())))
            paras = tuple([json.dumps(val) if isinstance(val, dict) or isinstance(val, list) else val for val in d.values()])
            fid = self.exe_dml(sql, paras)
        else: # update
            sql = "UPDATE {0} SET {1} WHERE fid = %s".format(table_name, ", ".join([key + " = %s" for key in d.keys()]))
            paras = tuple([json.dumps(val) if isinstance(val, dict) or isinstance(val, list) else val for val in d.values()])
            paras += (fid,)
            self.exe_dml(sql, paras)
        d["fid"] = fid
        return d

    def __get_pandas_connect_engine(self):
        return create_engine('mssql+pymssql://{0}:{1}@{2}:{3}/{4}'.format(
                             self.connection_info["user"],
                             self.connection_info["password"],
                             self.connection_info["server"],
                             self.connection_info["port"],
                             self.connection_info["database"]))

    def get_pandas_data_frame(self, sql: str):
        """
        Get data from sql and carry it in pandas DataFrame. 
        Note that all empty or white empty strings will be denoted by np.nan

        [Parameters]
        sql: sql literal

        [Returns]
        A DataFrame
        """
        engine = self.__get_pandas_connect_engine()

        df = None
        try:
            with engine.begin() as conn:
                df = pd.read_sql_query(sql = text(sql), con = conn)
        except Exception as e:
            print(e)
            raise Exception(str(e.args))
        # Replacing all empty or white empty string with np.nan for the missing value treatment in sklearn
        return df.replace(r'^\s*$', np.nan, regex=True)