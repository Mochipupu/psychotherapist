﻿import base64
from datetime import datetime

def __get_key():
    a = datetime.today().strftime('%Y-%m-%d')
    k = ""
    for x in range(100):
        k += a
    return k

def enctry(s):
    k = __get_key()
    encry_str = ""
    for i, j in zip(s, k):
        encry_str += (str(ord(i) + ord(j)) + '_')
    s1 = base64.b64encode(encry_str.encode("utf-8")).decode('UTF-8')
    return s1

def dectry(s):
    k = __get_key()
    p = base64.b64decode(s).decode('UTF-8')
    dec_str = ""
    for i, j in zip(p.split("_")[:-1], k):
        dec_str += (chr(int(i) - ord(j)))
    return dec_str