﻿class ORM(object):

    def __init__(self, **kwargs):
        list_keys = list(kwargs.keys())
        for k in self.__dict__.keys():
            if not callable(getattr(self, k)) and not k.startswith("_") and k in list_keys:
                self.__dict__[k] = kwargs[k]
        # self.__dict__.update((k, v) for k, v in kwargs.items() if not callable(getattr(self, k)) and not k.startswith("_"))

    def __str__(self) -> str:
        list_ = []
        for k, v in self.__dict__.items():
            if not callable(getattr(self, k)) and not k.startswith("_"):
                list_.append("{0}: {1}".format(k, v))
        return "\n".join(list_)
        
    def __eq__(self, that: object) -> bool:
        if (type(self).__name__ != type(that).__name__):
            return False
        if (hasattr(self, "fid") and hasattr(that, "fid")) and (self.fid > 0 and that.fid > 0):
            return self.fid == that.fid
        for k, v in self.__dict__.items():
            if not callable(getattr(self, k)) and not k.startswith("_") and k != 'fid':
                if (v != getattr(that, k)):
                    return False
        return True

    def __hash__(self) -> int:
        return hash(tuple([v for k, v in self.__dict__.items() if not callable(getattr(self, k)) and not k.startswith("_")]))

    def __jsonencode__(self):
        d = { k: v for k, v in self.__dict__.items() if not callable(getattr(self, k)) and not k.startswith("_") }
        return d


class Report(ORM):
    
    def __init__(self, **kwargs):

        self.fid = 0;
        self.HospitalID = 0;
        self.AmbulanceStationID = 0;
        self.MotherID = 0;
        self.BabyID = 0;
        self.ReferralReasons = "";
        self.Address = "";
        self.HospitalContactID = 0;
        self.OperationID = 0;
        self.AmbulanceDriverID = 0;
        self.AmbulancePhysicianID = 0;
        self.AmbulanceNurseID = 0;
        self.AttendingPhysicianID = 0;
        self.ApplicationNurseID = 0;
        self.ApplicationPhysicianID = 0;
        self.Applicant = 0;
        self.KMUReceiverID = 0;
        self.KMUReceiveDate = "";
        self.AmbulanceReceiverID = 0;
        self.AmbulanceReceiveDate = "";
        self.AttendDate = "";
        self.ArriveHospitalDate = "";
        self.LeaveHospitalDate = "";
        self.ReturnKMUDate = "";
        self.ReturnPediatricsDate = "";
        self.TherapyUnit = "";
        self.CreatedOn = "";
        self.CloseDate = "";
        self.IsActive = 1;
        self.DeletedBy = "";
        
        if kwargs:
            super().__init__(**kwargs)

    def __jsonencode__(self):
        return super(Report, self).__jsonencode__()

class Mother(ORM):
    
    def __init__(self, **kwargs):

        self.fid = 0;
        self.TID = "";
        self.Name = "";
        self.BirthDate = "";
        self.BloodType = "";
        self.RHType = "";
        self.Gravida = 0;
        self.Para = 0;
        self.Antibody = "";
        self.BloodTest = "";
        self.PastHistory = "";
        
        if kwargs:
            super().__init__(**kwargs)

    def __jsonencode__(self):
        return super(Mother, self).__jsonencode__()

class Baby(ORM):
    
    def __init__(self, **kwargs):
        
        self.fid = 0;
        self.MotherID = 0;
        self.Gender = "";
        self.BirthDate = "";
        self.BirthTime = "";
        self.EstimatedDueDate = "";
        self.PregnantWeek = "";
        self.BirthWeight = "";
        self.CurrentWeight = "";
        self.BodyLength = "";
        self.HeadLength = "";
        self.ChestLength = "";

        self.BeforeTemperature = "";
        self.BeforePulse = "";
        self.BeforeRespiration = "";
        self.BeforeSpO2 = "";
        self.BeforeAt = "";
        self.Treat = "";
        self.TreatTemperature = "";
        self.TreatPulse = "";
        self.TreatRespiration = "";
        self.TreatSpO2 = "";
        self.TreatAt = "";
        self.Handle = "";
        self.Feed = "";

        self.ApgarScore1 = 0;
        self.ApgarScore5 = 0;
        self.ApgarScore10 = 0;
        self.DOIC = "";
        
        if kwargs:
            super().__init__(**kwargs)

    def __jsonencode__(self):
        return super(Baby, self).__jsonencode__()

class Operation(ORM):
    
    def __init__(self, **kwargs):
        
        self.fid = 0;
        self.MotherID = 0;
        self.BabyID = 0;
        self.BirthType = "";
        self.AnesthesiaType = "";
        self.BirthProcess = "";
        self.RuptureMembranesDate = "";
        self.RuptureMembranesTime = "";
        self.FetalPosition = "";
        self.GBSTest = "";
        self.CatchCold = "";
        self.HaveFever = "";
        self.PregnancyComplications = "";
        self.Drugs = "";
        self.BloodLoss = 0;
        self.AmnioticFluid = "";

        if kwargs:
            super().__init__(**kwargs)

    def __jsonencode__(self):
        return super(Operation, self).__jsonencode__()

    
class ContactPerson(ORM):
    
    def __init__(self, **kwargs):
        
        self.fid = 0;
        self.Phone = "";
        self.CellPhone = "";
        self.ContactPerson = "";

        if kwargs:
            super().__init__(**kwargs)

    def __jsonencode__(self):
        return super(ContactPerson, self).__jsonencode__()


class AmbulanceVitals(ORM):

    def __init__(self, **kwargs):
        
        self.fid = 0;
        self.ReportID = 0;
        self.At = "";
        self.Temperature = 0;
        self.Pulse = 0;
        self.Respiration = 0;
        self.SpO2 = 0;
        self.BloodPressure = "";
        self.IsAvailable = 1;

        if kwargs:
            super().__init__(**kwargs)

    def __jsonencode__(self):
        return super(AmbulanceVitals, self).__jsonencode__()

# print(Report().__jsonencode__())