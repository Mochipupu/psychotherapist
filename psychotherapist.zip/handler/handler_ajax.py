﻿import json
from html import escape
from datetime import datetime

from django.http import HttpRequest

from .handler_enum import *
from .handler_enctry import *
from .handler_sql import server_name, handler_sql
from .handler_models import *
from .handler_tags import *
from .utils import *
    
class handler_ajax_request:
    
    def __init__(self, request: HttpRequest, session: dict) -> None:
        self.request = request
        self.r_act = request_act(int(request.POST.get('r')))
        self.r_type = request_type(int(request.POST.get('t')))
        self.request_para = request.POST.get('c')
        self.session = session
        self.now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
    def get_result(self) -> str:

        try:
            if (self.r_act == request_act.Insert):
                if (self.r_type == request_type.BSRS): # 新增修改BSRS
                    return self._BSRS_insert_update(self.request_para)
                elif (self.r_type == request_type.Depression): # 新增修改Depression
                    return self._Depression_insert_update(self.request_para)
                elif (self.r_type == request_type.Chat): # 新增Chat
                    return self._Chat_insert_update(self.request_para)
                elif (self.r_type == request_type.MatchMaking): # 新增Chat
                    return self._Chat_insert_update(self.request_para)
                else:
                    raise Exception("參數有誤")

            
            elif (self.r_act == request_act.Select):
                if (self.r_type == request_type.KeepAlive): # 檢查是否有轉診申請
                    return self._keep_alive(self.request_para)
                if (self.r_type == request_type.Login): # 帳號登入
                    return self._login(self.request_para)
                elif (self.r_type == request_type.Logout): # 帳號登出
                    return self._logout(self.request_para)
                else:
                    raise Exception("參數有誤")

            else:
                raise Exception("參數有誤")

        except Exception as e:
            print(str(e))
            raise Exception(e)


    def _login(self, para) -> str:
        
        try:
            kv = json.loads(para)
            account, password = kv["Key"].upper(), kv["Value"]

            sql = "SELECT * FROM {0} WHERE UserID = %s AND Password = %s AND IsActive = '1'".format("AccountTable")
            list_dicts = handler_sql(server_name.home).get_list_dicts(sql, (account, password))
            if (len(list_dicts) == 1):
                session_handler(self.request).set_session(list_dicts[0])
                return ""
            else:
                return "帳號或密碼不正確"

        except Exception as ex:
            raise Exception(ex)

    def _logout(self, para) -> str:
        
        try:
            session_handler(self.request).logout()
            return ""
        except Exception as ex:
            raise Exception(ex)

    def _keep_alive(self, para) -> None:
        return None

    def _BSRS_insert_update(self, para) -> str:

        try:
            sql = "SELECT * FROM {0} WHERE UserFid = %s".format("BSRS")
            params = (self.session["fid"], para)
            msg = "無法新增BSRS量表"

            list_dicts = handler_sql(server_name.home).get_list_dicts(sql, (self.session["fid"]))
            if (len(list_dicts) == 0): # 新增
                sql = "INSERT INTO {0} (UserFid, Answers) VALUES (%s, %s) ".format("BSRS")
            else: # 更新
                sql = "UPDATE {0} SET Answers = %s WHERE UserFid = %s".format("BSRS")
                msg = "無法更新BSRS量表"
                params = (para, self.session["fid"])
            try:
                handler_sql(server_name.home).exe_dml(sql, params)
            except :
                raise Exception(msg)
            return ""
        except Exception as ex:
            raise Exception(ex)

    def _Depression_insert_update(self, para) -> str:

        try:
            sql = "SELECT * FROM {0} WHERE UserFid = %s".format("Depression")
            params = (self.session["fid"], para)
            msg = "無法新增台灣人憂鬱量表"

            list_dicts = handler_sql(server_name.home).get_list_dicts(sql, (self.session["fid"]))
            if (len(list_dicts) == 0): # 新增
                sql = "INSERT INTO {0} (UserFid, Answers) VALUES (%s, %s) ".format("Depression")
            else: # 更新
                sql = "UPDATE {0} SET Answers = %s WHERE UserFid = %s".format("Depression")
                msg = "無法更新台灣人憂鬱量表"
                params = (para, self.session["fid"])
            try:
                handler_sql(server_name.home).exe_dml(sql, params)
            except :
                raise Exception(msg)
            return ""
        except Exception as ex:
            raise Exception(ex)

    def _Chat_insert_update(self, para) -> str:

        try:
            response = get_gemini_response("如果你是一位心理諮商師，請依據以下內容進行對話回覆(限制最多200個字)，不能存在有任何負面能量：" + para)
            response = response.replace("\n", "")
            list_params = [ (self.session["fid"], para, self.now), (self.session["fid"], response, self.now) ]
            try:
                for params in list_params:
                    handler_sql(server_name.home).exe_dml("INSERT INTO Chat (UserFid, ChatContent, CreatedOn) VALUES (%s, %s, %s)", params)
            except Exception as e:
                raise Exception('無法傳送聊天內容')
            return response
        except Exception as ex:
            raise Exception(ex)