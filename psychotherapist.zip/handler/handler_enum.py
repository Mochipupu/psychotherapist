﻿from enum import IntEnum

class request_act(IntEnum):
    # request_act.Insert.name -> Insert; request_act.Insert.value -> 1
    none = 0
    Insert = 1
    Update = 2
    Delete = 3
    Select = 4
    Close = 5

class request_type(IntEnum):
    none = 0,
    KeepAlive = 1,
    ''' 持續查詢案件狀況 '''
    Login = 2,
    ''' 登入系統 '''
    Logout = 3,
    ''' 登出系統 '''
    Account = 4,
    ''' 帳號 '''
    BSRS = 5,
    ''' BSRS量表 '''
    Depression = 6,
    ''' 台灣人憂鬱量表 '''
    Chat = 7,
    ''' 聊天 '''
    MatchMaking = 8,
    ''' 媒合 '''

class Toolbar_types(IntEnum):
    # request_act.Insert.name -> Insert; request_act.Insert.value -> 1
    none = 0
    Insert = 1
    Questionnaire = 2
    Match = 3
    Title_match_result = 4
    Title_main = 5