﻿import json
import requests

from django.conf import settings

class google_maps:

	def __init__(self) -> None:
		self.key = settings.GOOGLE_MAP_KEY

	def get_distance_time(self, address1, address2):

		params = {'key': self.key, 'origins': address1, 'destinations': address2 }

		url = 'https://maps.googleapis.com/maps/api/distancematrix/json?'
		d = requests.get(url, params=params)
		d = json.loads(d.text)

		return d['rows'][0]['elements'][0]['distance']['text'], d['rows'][0]['elements'][0]['duration']['text']
