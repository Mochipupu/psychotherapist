﻿import random, math, json#, copy

from django.conf import settings

# from .handler_sql import server_name, handler_sql
from .handler_enum import *

    
def get_page_navigator(data_count: int, page_index) -> str:

    row_size = settings.DEFAULT_LIST_ROW_COUNT

    page_begin = int(float(page_index - 1) / row_size) * row_size + 1
    page_end = page_begin + row_size - 1

    # 取得總頁數
    total_pages = math.ceil(float(data_count) / row_size)
    if (total_pages == 0):
        total_pages, page_index = 1, 1
    # 資料筆數：{items} 頁數：{nowpage}/{pages}
    summary = "<span>資料筆數【{0}】 頁數【<span class='pageIndex'>{1}</span>/{2}】</span>".format(data_count, page_index, total_pages)

    # 設定頁碼|1|2|3|4|5|
    IndexHtml = ""
    if (page_end > total_pages):
        page_end = total_pages

    for i in range(page_begin, page_end + 1):
        IndexHtml += "<li><a class='pageNumber{0}' data-value='{1}'>{1}</a></li>".format(" active" if (i == page_index) else "", i)

    # 第一頁|上一頁
    prevIndex = page_index - 1
    if (prevIndex <= 0):
        prevIndex = 1
    PreHtml = "<li><a class='dm-paginator_btn firstPage' data-value='{0}' title='第一頁'><<</a></li>".format(1) + \
              "<li><a class='dm-paginator_btn prevPage' data-value='{0}' title='上一頁'><</a></li>".format(prevIndex)
    # 下一頁|最末頁
    nextIndex = page_index + 1
    if (nextIndex > total_pages):
        nextIndex = total_pages;
    NextHtml = "<li><a class='dm-paginator_btn nextPage' data-value='{0}' title='下一頁'>></a></li>".format(nextIndex) + \
        "<li><a class='dm-paginator_btn lastPage' data-value='{0}' title='最末頁'>>></a></li>".format(total_pages)

    page = "<ul class='dm-pagination dm-paginator_buttons'>{0}{1}{2}</ul>".format(PreHtml, IndexHtml, NextHtml)

    return "<div class='dm-paginator'><nav role='navigation'>{0}</nav><div class='dm-paginator_number'>{1}</div></div>".format(page, summary)

def get_select_options(list_: list, selected_value: str) -> str:

    tags = "<option value='0'>&nbsp;&nbsp;請選擇</option>".format(" selected" if len(selected_value.strip()) == 0 else "")

    if (len(list_) == 0):
        return tags

    if (isinstance(list_[0], dict)):
        for d in list_:
            key, val = d["Key"].strip(), d["Value"].strip()
            tags += "<option value='{0}'{1}>&nbsp;&nbsp;{2}</option>".format(key, " selected" if selected_value == key else "", val)
    elif (isinstance(list_[0], str)):
        for d in list_:
            val = d.strip()
            tags += "<option value='{0}'{1}>&nbsp;&nbsp;{2}</option>".format(val, " selected" if selected_value == val else "", val)
    else:
        for d in list_:
            val = str(d).strip()
            tags += "<option value='{0}'{1}>&nbsp;&nbsp;{2}</option>".format(val, " selected" if selected_value == val else "", val)

    return tags

def get_left_functions(session: dict, requestParas: dict):
    """
    Get left bar's front functions in the form of Html tags.

    [Parameters]
    session: a dictionary for a user's profile.
    requestParas: the passed request parameters.

    [Returns]
    str: the Html tags of left bar's functions.
    listParentFunctions: a list of dictionaries (visible parent front functions).
    """
    
    typeCode = requestParas["TypeCode"].strip().lower()
    list_functions = [d for d in settings.FRONT_FUNCTIONS if (d["IsAdmin"] <= session["IsAdmin"] and d["Visible"] == 1)]
    listParentFunctions = sorted([d for d in list_functions if d['ParentID'] == 0], key = lambda f: f["Sort"], reverse = False)

    listMenu = []

    for pf in listParentFunctions:
        
        parentLi = ""
        listChlidFunctions = sorted([d for d in list_functions if d['ParentID'] == pf['fid']], key = lambda f: f["Sort"], reverse = False)
        
        if (len(listChlidFunctions) == 0):
            isActive = True if (pf['TypeCode'].lower() == typeCode) else False
            parentLi = "<a data-type='{0}' class='{1}' title='{2}'><i class='{3}'></i><span>{2}</span></a>".format(
                        pf["TypeCode"],
                        "active" if (isActive) else "",
                        pf["Item"],
                        pf["Icon"])
        else:
            listChildrenLi = []
            for f in listChlidFunctions:
                isActive = True if (f["TypeCode"].lower() == typeCode) else False

                listChildrenLi.append(
                    "<li><a data-type='{0}' class='{1}' title='{2}'><i class='{3}'></i><span>{2}</span></a></li>".format(
                        f["TypeCode"], "active" if (isActive) else "", f["Item"], f["Icon"]))
            
            parentLi = "<a data-type='' class='{0}' title='{1}'><i class='{2}'></i><span>{1}</span><i class='fas fa-caret-{3} floatR'></i></a>".format(
                        "active" if (isActive) else "", pf["Item"], pf["Icon"], "down" if (isActive) else "right")
            parentLi = "{0}<ul class='dm-submenu'>{1}</ul>".format(parentLi, "".join(listChildrenLi))

        listMenu.append("<li>{0}</li>".format(parentLi))

    return "".join(listMenu), listParentFunctions

def get_home_functions(listParentFunctions: list) -> str:

    list_bgcolors = ["dm-bgBlue", "dm-bgPurple", "dm-bgRed", "dm-bgGreen", "dm-bgGrey", "dm-bgBlack"]
    bgcolor_count = len(list_bgcolors) - 1
    liTags = ""

    for pf in listParentFunctions:
        color = list_bgcolors[random.randint(0, bgcolor_count)]
        liTags += "<div class='iconItem'>" + \
                    "<a class='iconContainer' data-type='{0}' title='{1}'>".format(pf["TypeCode"], pf["Item"]) + \
                        "<span class='{0}'><i class='{1}'></i></span></a>".format(color, pf["Icon"]) + \
                    "<div class='portfolioIconTitle forbidSelect' style='color:#e77817'>{0}</div></div>".format(pf["Item"])
    return liTags

def get_head_functions(toolbar_types: Toolbar_types):

    if (toolbar_types == Toolbar_types.Match):
        return "".join([
            "<ul class='ulInsertNew'>",
                "<li><a class='jMatch' title='媒合心理師'><i class='fas fa-project-diagram'></i><p>媒合心理師</p></a></li>",
            "</ul>"])

    elif (toolbar_types == Toolbar_types.Questionnaire):
        return "".join([
            "<ul class='ulInsertNew'>",
                "<li class='liPrevious'><a class='jPrevious' title='上一步'><i class='far fa-caret-square-left'></i><p>上一步</p></a></li>",
                "<li class='liNext'><a class='jNext' title='下一步'><i class='far fa-caret-square-right'></i><p>下一步</p></a></li>",
                "<li class='liSend'><a class='jSend' title='送出量表'><i class='far fa-paper-plane'></i><p>送出量表</p></a></li>",
            "</ul>",])
        
    elif (toolbar_types == Toolbar_types.Title_match_result):
        return "<span>媒合結果</span>"
    
    elif (toolbar_types == Toolbar_types.Title_main):
        return "<span>心理諮商師媒合系統</span>"
    

    else:
        return "".join([
            "<ul class='ulInsertNew'>",
            "</ul>"])

def get_psychotherapist_tags(d_psychotherapies):
    list_psychotherapies = []
    for score, psychotherapy in d_psychotherapies.items():
        suggest_degree = round(((80 - score) / 80) * 100, 0)
        list_psychotherapies.append(
            "".join(["<div class='psychotherapy' data-value='{0}'>".format(json.dumps(psychotherapy["data"])),
                "<div class='suggest'><div class='suggest_score'><p>推薦</p><p>{0}</p></div></div>".format(suggest_degree),
                "<div class='image' style='background: url(../../../static/app/images/{0}) no-repeat;'></div>".format(psychotherapy["image"]),
                "<div class='info'>",
                    "<div class='name'>{0}</div>".format(psychotherapy["Name"]),
                    "<div class='tel'>{0}</div>".format(psychotherapy['Tel']),
                    "<div class='address'>{0}</div>".format(psychotherapy['Address']),
                    "<div class='expertise'>",
                        "<ol>",
                            "<li>自我探索：<span class='score'>{0}</span></li>".format(psychotherapy["SelfExploration"]),
                            "<li>工作職涯：<span class='score'>{0}</span></li>".format(psychotherapy["CareerInterests"]),
                            "<li>人際互動：<span class='score'>{0}</span></li>".format(psychotherapy["InterpersonalInteraction"]),
                            "<li>情緒壓力：<span class='score'>{0}</span></li>".format(psychotherapy["EmotionalStress"]),
                            "<li>感情關係：<span class='score'>{0}</span></li>".format(psychotherapy["Relationships"]),
                            "<li>親職教養：<span class='score'>{0}</span></li>".format(psychotherapy["Parenting"]),
                            "<li>家庭關係：<span class='score'>{0}</span></li>".format(psychotherapy["FamilyDynamics"]),
                            "<li>性與性別：<span class='score'>{0}</span></li>".format(psychotherapy["SexAndGender"]),
                        "</ol></div></div></div>"]))
    return "".join(list_psychotherapies)