﻿import json
from datetime import datetime

from django.http import HttpRequest
from django.conf import settings

from google import genai

from .handler_enctry import *
from .handler_enum import *

def get_request_paras(request: HttpRequest):
    """
    取得使用者於前端傳入之請求內容

    [Parameters]
    request: Django的HttpRequest物件，乘載請求內容
    """
    d = { "Act": 0, "Fid": 0, "Keyword": "", "PageIndex": 1, 
          "Recipe": "", "Source": json.dumps([]), "TypeCode": "" }
    if request.method == 'POST': # 使用POST方式傳送至網站的 HttpRequest
        val = request.POST.get('r', None)
    elif request.method == 'GET': # 使用GET方式傳送至網站的 HttpRequest
        val = request.GET.get('r', None)
    else:
        pass
    if val is None:
        return d

    return json.loads(val)

class session_handler:
    """
    處理使用者登入後資訊
    """

    def __init__(self, request: HttpRequest) -> None:
        self.session_name = 'mis'
        self.request = request

    def get_session(self):
        """
        取得使用者資訊
        """
        try:
           session = self.request.session[self.session_name]
           session = dectry(session)
           session = json.loads(session)
           return session
        except :
           return None

    def set_session(self, d: dict) -> None:
        """
        使用者登入網站後，設定 session
        """
        _d = {
             "fid": d["fid"],
             "UserID": d["UserID"].strip(),
             "IsAdmin": d["IsAdmin"], }

        self.request.session[self.session_name] = enctry(json.dumps(_d))

    def logout(self) -> None:
        """
        登出網站 刪除session
        """
        del self.request.session[self.session_name]
        self.request.session.flush()
        print('')


def get_gemini_response(text) -> list:
    
    client = genai.Client(api_key = settings.GOOGLE_API_KEY)
    response = client.models.generate_content(
        model="gemini-2.0-flash", 
        contents = text
    )
    return response.text