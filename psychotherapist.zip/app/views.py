﻿import os, sys, json
from html import escape

from django.shortcuts import render
from django.http import HttpRequest, JsonResponse, HttpResponseRedirect
from django.views.decorators.csrf import ensure_csrf_cookie
from django.conf import settings
from sqlalchemy import JSON

sys.path.append('../')
from handler.handler_enctry import *
from handler.handler_sql import server_name, handler_sql
from handler.handler_ajax import *
from handler.handler_tags import *
from handler.handler_enum import *
from handler.utils import *

class page_loader:

    def __init__(self, request, session, requestParas, left_tags) -> None:
        self.request, self.session, self.requestParas, self.left_tags = request, session, requestParas, left_tags
        self.paras = escape(json.dumps(requestParas))
        self.d_render = { 'JsonParas': self.paras, 'leftbarlist': self.left_tags, 'KeepAlive': settings.KEEP_ALIVE }

    def get_user_control_content(self, ucName: str):
        file_path = os.path.join(settings.BASE_DIR, "app/templates/app/user_controls/{0}.html".format(ucName))
        if not os.path.exists(file_path):
            raise Exception("無法找到UserControl {0} 的路徑".format(ucName))

        list_uc_content = []
        with open(file_path, newline='', encoding='UTF-8-sig') as f:
            list_uc_content = f.readlines()
        return "".join(list_uc_content)

    
    def load_chat(self):
        self.d_render['headFunctions'] = get_head_functions(Toolbar_types.Match)
        

        # 取得聊天紀錄
        sql = "SELECT * FROM (SELECT TOP 4 * FROM Chat WHERE UserFid = %s ORDER BY fid DESC) AS Result ORDER BY Result.fid ASC"
        list_dicts = handler_sql(server_name.home).get_list_dicts(sql, (self.session["fid"]))
        if (len(list_dicts) > 0):
            for i in range(len(list_dicts)):
                self.d_render["Chat" + str(i)] = escape(list_dicts[i]["ChatContent"])
        # 量表
        for questionnaire in ["BSRS", "Depression"]:
            sql = "SELECT * FROM {0} WHERE UserFid = %s".format(questionnaire)
            list_dicts = handler_sql(server_name.home).get_list_dicts(sql, (self.session["fid"]))
            if (len(list_dicts) == 1):
                self.d_render[questionnaire] = list_dicts[0]["Answers"]


        return render(self.request, 'app/chat.html', self.d_render)

    def load_matchmaking(self):
        self.d_render['headFunctions'] = get_head_functions(Toolbar_types.Title_match_result)
        d_questionnaires = { "Chat": [] }
        prompt, prompt_content = "如果你是一位心理諮商師，請依據", ""
        # 取得聊天紀錄
        sql = "SELECT * FROM (SELECT TOP 4 * FROM Chat WHERE UserFid = %s ORDER BY fid DESC) AS Result ORDER BY Result.fid ASC"
        list_dicts = handler_sql(server_name.home).get_list_dicts(sql, (self.session["fid"]))
        if (len(list_dicts) > 0):
            for i in range(len(list_dicts)):
                if i % 2 == 0:
                    d_questionnaires["Chat"].append(list_dicts[i]["ChatContent"])
        # 量表
        for questionnaire in ["BSRS", "Depression"]:
            sql = "SELECT * FROM {0} WHERE UserFid = %s".format(questionnaire)
            list_dicts = handler_sql(server_name.home).get_list_dicts(sql, (self.session["fid"]))
            if (len(list_dicts) == 1):
                d_questionnaires[questionnaire] = list_dicts[0]["Answers"]
        if d_questionnaires["Chat"]:
            prompt += "以下聊天內容"
            prompt_content += "。".join(d_questionnaires["Chat"])
        if d_questionnaires["BSRS"]:
            prompt += "、以下BSRS-5量表分數分別為" + d_questionnaires["BSRS"]
        if d_questionnaires["Depression"]:
            prompt += "、以下台灣人憂鬱量表分數分別為" + d_questionnaires["Depression"]

        prompt = '{0}，{1}'.format(prompt, prompt_content)
        prompt += '只要回傳以下的格式並給予0~10分且無須任何解釋或提醒 {"自我探索":0,"工作職涯":0,"人際互動":0,"情緒壓力":0,"感情關係":0,"親職教養":0,"家庭關係":0,"性與性別":0}'
        response = get_gemini_response(prompt)
        print(response)
        response = response[response.index('{"自我探索"'):]
        response = response.replace('/n', '').replace('```', '')
        d_scores = json.loads(response)
        # d_scores = {"自我探索":8,"工作職涯":9,"人際互動":4,"情緒壓力":6,"感情關係":3,"親職教養":0,"家庭關係":0,"性與性別":0}
        d_psychotherapies = { }
        list_properties = ["SelfExploration","CareerInterests","InterpersonalInteraction","EmotionalStress","Relationships","Parenting","FamilyDynamics","SexAndGender"]
        sql = "SELECT * FROM Psychotherapies"
        list_dicts = handler_sql(server_name.home).get_list_dicts(sql)
        for i in range(len(list_dicts)):
            psychotherapy = list_dicts[i]
            dist, index = 0, 0
            for score in list(d_scores.values()):
                if score == 0:
                    index += 1
                    continue
                dist += abs(psychotherapy[list_properties[index]] - score)
                index += 1
            psychotherapy["data"] = [psychotherapy[prop] for prop in list_properties]
            d_psychotherapies[dist] = psychotherapy
        d_psychotherapies = dict(sorted(d_psychotherapies.items()))

        list_psychotherapies = get_psychotherapist_tags(d_psychotherapies)
        self.d_render['list_psychotherapies'] = list_psychotherapies
        self.d_render['scores'] = json.dumps(list(d_scores.values()))

        return render(self.request, 'app/matchmaking.html', self.d_render)
    
    def load_BSRS(self):
        self.d_render['headFunctions'] = get_head_functions(Toolbar_types.Questionnaire)

        sql = "SELECT * FROM {0} WHERE UserFid = %s".format("BSRS")
        list_dicts = handler_sql(server_name.home).get_list_dicts(sql, (self.session["fid"]))
        if (len(list_dicts) == 1):
            self.d_render["content"] = list_dicts[0]["Answers"]
        return render(self.request, 'app/BSRS.html', self.d_render)
                
    def load_depression(self):
        self.d_render['headFunctions'] = get_head_functions(Toolbar_types.Questionnaire)

        sql = "SELECT * FROM {0} WHERE UserFid = %s".format("Depression")
        list_dicts = handler_sql(server_name.home).get_list_dicts(sql, (self.session["fid"]))
        if (len(list_dicts) == 1):
            self.d_render["content"] = list_dicts[0]["Answers"]
        return render(self.request, 'app/depression.html', self.d_render)


def login(request):
    assert isinstance(request, HttpRequest)
    return render(request, 'app/login.html')

@ensure_csrf_cookie
def home(request):
    
    assert isinstance(request, HttpRequest)

    session = session_handler(request).get_session()
    if session is None:
        return HttpResponseRedirect('/login/')
    
    requestParas = get_request_paras(request)
    
    typeCode = requestParas["TypeCode"].strip().lower()
    left_tags, listParentFunctions = get_left_functions(session, requestParas)
    
    try:
        if len(typeCode) == 0:
            pageContent = get_home_functions(listParentFunctions)
            return render(request, 'app/home.html', { 'JsonParas': escape(json.dumps(requestParas)), 'leftbarlist': left_tags, 'pageContent': pageContent, 'headFunctions': get_head_functions(Toolbar_types.Title_main), 'KeepAlive': settings.KEEP_ALIVE })
            
        list_functions = [f for f in settings.FRONT_FUNCTIONS if f["TypeCode"].lower() == typeCode]
        if (len(list_functions) == 0 or len(list_functions) > 1):
            return render(request, 'app/error.html', { 'JsonParas': escape(json.dumps(requestParas)), 'pageContent': "查無參數{0}！請通知系統管理者".format(typeCode), })
        
        page = list_functions[0]["Url"].lower()

        loader = page_loader(request, session, requestParas, left_tags)

        if ("/chat.html" == page):
            return loader.load_chat()

        elif ("/matchmaking.html" == page):
            return loader.load_matchmaking()
                
        elif ("/bsrs.html" == page):
            return loader.load_BSRS()
                
        elif ("/depression.html" == page):
            return loader.load_depression()

    except Exception as e:
        print(e)
                

@ensure_csrf_cookie
def Handler_ajax(request):
    assert isinstance(request, HttpRequest)

    if request.method == "GET":
        return JsonResponse({'msg': 'error', 'content': "參數有誤"})

    session = session_handler(request).get_session()
    if (session is None and request_type(int(request.POST.get('t'))) != request_type.Login):
        return JsonResponse({'msg': 'error', 'content': "請先登入系統"})

    try:
        result = handler_ajax_request(request, session).get_result()
        return JsonResponse({ 'msg': 'OK', 'content': result })
    except Exception as e:
        error = str(e.args)
        if ("Exception" in error):
            error = error.replace("Exception", "").replace("(", "").replace(")", "")
        print(error) #, e.args
        return JsonResponse({'msg':'error', 'content':error})