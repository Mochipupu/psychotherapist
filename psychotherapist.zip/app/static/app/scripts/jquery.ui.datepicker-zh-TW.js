﻿/* Chinese initialisation for the jQuery UI date picker plugin. */
/* Written by Ressol (ressol@gmail.com). */
jQuery(function($){
    $.datepicker.regional['zh-TW'] = {
        closeText: '關閉',
        prevText: '&#x3c;上月',
        nextText: '下月&#x3e;',
        currentText: '今天',
        monthNames: ['一月', '二月', '三月', '四月', '五月', '六月', '七月', '八月', '九月', '十月', '十一月', '十二月'],
        monthNamesShort: ['一', '二', '三', '四', '五', '六', '七', '八', '九', '十', '十一', '十二'],
        dayNames: ['星期日', '星期一', '星期二', '星期三', '星期四', '星期五', '星期六'],
        dayNamesShort: ['周日', '周一', '周二', '周三', '周四', '周五', '周六'],
        dayNamesMin: ['日', '一', '二', '三', '四', '五', '六'],
        weekHeader: '周',
        dateFormat: 'yy/mm/dd',
        firstDay: 1,
        isRTL: false,
        showMonthAfterYear: true,
        yearSuffix: '年'
    };
    $.datepicker.setDefaults($.datepicker.regional['zh-TW']);

    //先設定預設西元年的datepicker必要功能
    var old_generateMonthYearHeader = $.datepicker._generateMonthYearHeader;
    var old_formatDate = $.datepicker.formatDate;
    var old_parseDate = $.datepicker.parseDate;

    $.extend($.datepicker, {
        //選擇日期之後的value
        formatDate: function (format, date, settings) {
            var oformatDate = old_formatDate(format, date, settings);
            if (format == 'Rmmdd') {
                var Y, M, D;
                var Y = date.getFullYear() - 1911;
                var M = ((date.getMonth() + 1) < 10) ? ('0' + (date.getMonth() + 1)) : (date.getMonth() + 1);
                var D = (date.getDate() < 10) ? ('0' + date.getDate()) : date.getDate();
                return Y + '-' + M + '-' + D;
            }
            return oformatDate;
        },
        //點取已存在日期的parse
        parseDate: function (format, value, settings) {
            if (format == 'Rmmdd') {
                var v = new String(value);
                var Y, M, D;
                Y = parseInt(v.split('-')[0]) + 1911;
                M = parseInt(v.split('-')[1]) - 1;
                D = parseInt(v.split('-')[2]);
                return (new Date(Y, M, D));
            } else {
                var oparseDate = old_parseDate.apply(this, [format, value, settings]);
                return (oparseDate);
            }
        },
        //改變小工具的年
        _generateMonthYearHeader: function (inst, drawMonth, drawYear, minDate, maxDate, secondary, monthNames, monthNamesShort) {
            var dateFormat = this._get(inst, 'dateFormat');
            var htmlYearMonth = old_generateMonthYearHeader.apply(this, [inst, drawMonth, drawYear, minDate, maxDate, secondary, monthNames, monthNamesShort]);
            if (dateFormat == 'Rmmdd') {
                if ($(htmlYearMonth).find('.ui-datepicker-year').length > 0) {
                    htmlYearMonth = $(htmlYearMonth).find('.ui-datepicker-year').find('option').each(function (i, e) {
                        if (Number(e.value) - 1911 > 0) { $(e).text(Number(e.textContent) - 1911); }
                    }).end().end().get(0).outerHTML;
                }
            }
            return htmlYearMonth;
        }
    });
});
