﻿/**
 * 限制輸入格式(數值 + /)
 * @param {any} $obj 物件
 * @param {any} regExpress regular expression
 */
function RestrictInputFormat($obj, regExpress) {
    var chkSum = $obj.val().replace(regExpress, '');
    $obj.val((chkSum === 0) ? '' : chkSum);
}
/**
 * 設定 TextBox 內容只能輸入數字 (透過 dm-txtnum 綁定輸入事件, maxLength:字數限制)
 * @param {any} maxLength 字數限制
 */
function Txtnumonly(maxLength) {
    $(".dm-txtnum").bind("keypress", function (e) {
        var ecode = e.charCode || e.keyCode;
        var oElement = e.target || e.srcElement;
        if (!e.shiftKey && !e.ctrlKey && !e.altKey) {
            if ((ecode > 47 && ecode < 58) ||
                ecode === 27 || ecode === 13) {
                oElement.value = oElement.value;
            } else {
                if (window.event) //IE
                    event.returnValue = false;
                else //Firefox
                    e.preventDefault();
            }
        }
    }).bind("keyup", function (e) {
        if ($(this).val().length > maxLength)
            $(this).val($(this).val().substr(0, maxLength));
    }).bind("beforepaste", function (e) {
        clipboardData.setData('text', clipboardData.getData('text').replace(/[^\d]/g, ''));
    }).prop("type", "number");
}
/** 設定 物件 Focus() */
(function ($) {
    $.fn.setfocus = function () {
        return this.each(function () {
            var dom = this;
            setTimeout(function () {
                try { dom.focus(); } catch (e) { console.log(e); }
            }, 0);
        });
    };
})(jQuery);
/** 輸入字數 TextArea */
(function ($) {
    $.fn.textareaCounter = function (options) {
        // setting the defaults $("textarea").textareaCounter({ limit: 100 });
        var defaults = {
            limit: 100
        };
        var opt = $.extend(defaults, options);
        // and the plugin begins
        return this.each(function () {
            var obj, text, wordcount, limited;
            obj = $(this);
            obj.after('<span style="font-size: 11px; clear: both; margin-top: 3px; display: block;" id="counter-text">Max. ' + opt.limit + ' words</span>');
            obj.keyup(function () {
                text = obj.val();
                if (text === "") {
                    wordcount = 0;
                } else {
                    wordcount = $.trim(text).split(" ").length;
                }
                if (wordcount > opt.limit) {
                    $("#counter-text").html('<span style="color: #DD0000;">0 words left</span>');
                    limited = $.trim(text).split(" ", opt.limit);
                    limited = limited.join(" ");
                    $(this).val(limited);
                } else {
                    $("#counter-text").html((opt.limit - wordcount) + ' words left');
                }
            });
        });
    };
})(jQuery);
/**
 * 判定是否為 Mobile 裝置
 * @returns {boolean} true/false
 */
function isMobile() {
    var test1 = (/(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|ipad|iris|kindle|Android|Silk|lge |maemo|midp|mmp|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows (ce|phone)|xda|xiino/i.test(navigator.userAgent)
        || /1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i.test(navigator.userAgent.substr(0, 4)));
    var test2 = (navigator.userAgent.match(/(iPhone|iPod|iPad|Android|playbook|silk|BlackBerry|BB10|Windows Phone|Tizen|Bada|webOS|IEMobile|Opera Mini)/) === null) ? false : true;
    return (test1 && test2);
}
/**
 * 檢查text內容，有問題回傳字串/無問題回傳""
 * @param {string} s 傳入的文字字串
 * @returns {string} 結果
 */
function CheckTextContent(s) {
    return (s.match(/script/gi)) ? '本網站不支援script的寫入' : "";
}
/**
 * 檢查手機號碼
 * @param {string} s 傳入的文字字串
 * @returns {string} 結果
 */
function CheckCellPhoneNumber(s) {
    return (s.match(/((?=(09))[0-9]{10})$/g)) ? '' : '手機號碼有誤';
}
/**
 * 回傳$obj轉換 float 的值，當 isNaN 回傳 0
 * @param {any} $obj 傳入的物件
 * @returns {number} float數值
 */
function GetFloatValue($obj) {
    if (typeof $obj === 'string')
        return (isNaN($obj)) ? 0 : parseFloat($obj);
    var nodeName = $obj.prop('nodeName'), value;
    switch (nodeName) {
        case "INPUT":
        case "SELECT":
            value = $obj.val().trim();
            break;
        default:
            value = $obj.text().trim();
            break;
    }
    return (isNaN(value)) ? 0 : parseFloat(value);
}
/**
 * 非email回傳 true/false
 * @param {string} s 傳入的文字字串
 * @returns {boolean} true/false
 */
function IsEmailFormat(s) {
    return (s.search(/^[\w-]+(\.[\w-]+)*@[\w-]+(\.[\w-]+)+$/) !== -1);
}
/**
 * 台灣公司統編檢查
 * @param {any} taxId 傳入的統編字串
 * @returns {boolean} true/false
 */
function IsMeetBusinessNo(taxId) {
    var invalidList = "00000000,11111111";
    if (/^\d{8}$/.test(taxId) === false || invalidList.indexOf(taxId) !== -1)
        return false;
    // 使用「正規表達式」檢驗格式
    if (taxId.search(/\d{8}/) === -1) {
        return false;
    } else {
        var cx = [1, 2, 1, 2, 1, 2, 4, 1];
        //將字串分割為陣列(IE必需這麼做才不會出錯)
        var cnum = taxId.split('');
        //計算總分
        var total = 0;
        for (var i = 0; i <= 7; i++) {
            var n = parseInt(cnum[i]) * cx[i];
            total += (n < 10) ? n : (Math.floor(n / 10) + (n % 10));
        }
        return ((total % 10 === 0) || (cnum[6] === 7 && (total + 1) % 10 === 0)) ? true : false;
    }
}

/**
 * 檢查輸入字串是否包含中文字
 * @param {string} input
 */
function IsInputHasChineseChar(input) {
    var regEx = /^[^\u4E00-\u9FA5]*$/;
    return (!input.match(regEx)) ? true : false;
}

/**
 * 檢查日期格式(正確回傳true)
 * @param {string} date 傳入的日期
 * @returns {boolean} true/false
 */
function IsValidDate(date) {
    var regEx = /^\d{4}-\d{2}-\d{2}$/;
    if (!date.match(regEx)) return false;  // Invalid format
    var d;
    if (!((d = new Date(date)) | 0)) return false; // Invalid date (or this could be epoch)
    return d.toISOString().slice(0, 10) === date;
}

function IsValidTime(time) {
    return /^(?:[01][0-9]|2[0-3]):[0-5][0-9](?::[0-5][0-9])?$/.test(time);
}

function IsValidDateTime(time) {
    return /[0-9]{4}-(0[1-9]|1[0-2])-(0[1-9]|[1-2][0-9]|3[0-1]) (2[0-3]|[01][0-9]):[0-5][0-9](?::[0-5][0-9])?$/.test(time);
}

function IsValidCellPhone(num) {
    return ("0922242110".match(/^(09)[0-9]{8}$/)) ? true : false;
}

function IsMeetTID(pid) {

    studIdNumber = pid.toUpperCase();
    var nationality = 0;
    //驗證填入身分證字號長度及格式
    if (studIdNumber.length != 10) return false;
    //格式，用正則表示式比對第一個字母是否為英文字母
    var isTID = (!isNaN(studIdNumber.substr(1, 9)) && (/^[A-Z]$/.test(studIdNumber.substr(0, 1)))),
        isNotTID = (!isNaN(studIdNumber.substr(2, 8)) && (/^[A-Z]$/.test(studIdNumber.substr(0, 1))) && (/^[A-Z]$/.test(studIdNumber.substr(1, 1))));
    if (!isTID && !isNotTID) return false;
    nationality = isTID ? 0 : 1;
    var idHeader = "ABCDEFGHJKLMNPQRSTUVXYWZIO"; //按照轉換後權數的大小進行排序
    //本國人
    if (nationality == 0) {
        //這邊把身分證字號轉換成準備要對應的
        studIdNumber = (idHeader.indexOf(studIdNumber.substring(0, 1)) + 10) + '' + studIdNumber.substr(1, 9);
        //開始進行身分證數字的相乘與累加，依照順序乘上1987654321
        s = parseInt(studIdNumber.substr(0, 1)) +
            parseInt(studIdNumber.substr(1, 1)) * 9 +
            parseInt(studIdNumber.substr(2, 1)) * 8 +
            parseInt(studIdNumber.substr(3, 1)) * 7 +
            parseInt(studIdNumber.substr(4, 1)) * 6 +
            parseInt(studIdNumber.substr(5, 1)) * 5 +
            parseInt(studIdNumber.substr(6, 1)) * 4 +
            parseInt(studIdNumber.substr(7, 1)) * 3 +
            parseInt(studIdNumber.substr(8, 1)) * 2 +
            parseInt(studIdNumber.substr(9, 1));

        checkNum = parseInt(studIdNumber.substr(10, 1));
        //模數 - 總和/模數(10)之餘數若等於第九碼的檢查碼，則驗證成功
        //若餘數為0，檢查碼就是0
        return ((s % 10) == 0 || (10 - s % 10) == checkNum) ? true : false;
    } else { //外籍生，居留證號規則跟身分證號差不多，只是第二碼也是英文字母代表性別，跟第一碼轉換二位數字規則相同，但只取餘數
        //這邊把身分證字號轉換成準備要對應的
        studIdNumber = (idHeader.indexOf(studIdNumber.substring(0, 1)) + 10) +
            '' + ((idHeader.indexOf(studIdNumber.substr(1, 1)) + 10) % 10) + '' + studIdNumber.substr(2, 8);
        //開始進行身分證數字的相乘與累加，依照順序乘上1987654321
        s = parseInt(studIdNumber.substr(0, 1)) +
            parseInt(studIdNumber.substr(1, 1)) * 9 +
            parseInt(studIdNumber.substr(2, 1)) * 8 +
            parseInt(studIdNumber.substr(3, 1)) * 7 +
            parseInt(studIdNumber.substr(4, 1)) * 6 +
            parseInt(studIdNumber.substr(5, 1)) * 5 +
            parseInt(studIdNumber.substr(6, 1)) * 4 +
            parseInt(studIdNumber.substr(7, 1)) * 3 +
            parseInt(studIdNumber.substr(8, 1)) * 2 +
            parseInt(studIdNumber.substr(9, 1));

        //檢查號碼 = 10 - 相乘後個位數相加總和之尾數。
        checkNum = parseInt(studIdNumber.substr(10, 1));
        //模數 - 總和/模數(10)之餘數若等於第九碼的檢查碼，則驗證成功
        ///若餘數為0，檢查碼就是0
        return ((s % 10) == 0 || (10 - s % 10) == checkNum) ? true : false;
    }
}
//===========Return Event===========
/**
 * 回傳浮點數
 * @param {any} value 傳入的文字
 * @param {any} digit 小數點位數
 * @returns {number} 浮點數值
 */
function ReturnFloat(value, digit) {
    var v = parseFloat(value);
    digit = (typeof digit === 'undefined') ? 3 : digit;
    return (isNaN(v) || v < 0) ? '' : (Math.round(v * Math.pow(10, digit)) / Math.pow(10, digit));
}
/**
 * 取得 Url Query String
 * @param {any} name 查詢的參數名稱
 * @param {any} url 傳入的網址字串
 * @returns {string} 參數值
 */
function GetParameterByName(name, url) {
    if (!url) url = window.location.href;
    name = name.replace(/[\[\]]/g, "\\$&");
    var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
        results = regex.exec(url);
    if (!results) return null;
    if (!results[2]) return '';
    return decodeURIComponent(results[2].replace(/\+/g, " "));
}
/**
 * 設定傳遞參數
 * @param {object} paras 參數
 */
function SetRequestParameters(paras) {
    $('#hfJsonParas').val(JSON.stringify(paras));
}
/**
 * 回傳傳遞參數物件
 * @returns {object} RequestParameter 物件
 */
function GetRequestParameters() {
    return JSON.parse($('#hfJsonParas').val().trim());
}
/**
 * 回傳傳遞參數內容
 * @param {string} name 參數名稱
 * @returns {string} 參數值
 */
function GetRequestParametersByName(name) {
    return JSON.parse($('#hfJsonParas').val().trim())[name];
}
/**
 * 更新傳遞參數內容
 * @param {string} key 參數名稱
 * @param {string} value 參數內容
 */
function UpdateRequestParametersByName(key, value) {
    var para = new RequestParameters(JSON.parse($('#hfJsonParas').val().trim()));
    para[key] = value;
    $('#hfJsonParas').val(JSON.stringify(para));
}

/**
 * 將日期進行加減
 * @param {string} inDate 日期文字
 * @returns {Date} 日期物件
 */
function AddDays(days, inDate) {
    var result = (inDate === undefined || inDate.trim().length === 0) ? new Date() : new Date(inDate);
    result.setDate(result.getDate() + days);
    return result;
}

/**
 * 將日期轉成yyyy-MM-dd HH:mm:ss文字格式
 * @param {Date} inDate 日期物件
 * @returns {string} 組成的日期字串
 */
function GetCustomNow(inDate) {
    if (inDate === undefined)
        inDate = new Date();
    var month = inDate.getMonth() + 1;
    if (month < 10)
        month = "0" + month;
    var date = inDate.getDate();
    if (date < 10)
        date = "0" + date;
    var hour = inDate.getHours();
    if (hour < 10)
        hour = "0" + hour;
    var minute = inDate.getMinutes();
    if (minute < 10)
        minute = "0" + minute;
    var second = inDate.getSeconds();
    if (second < 10)
        second = "0" + second;
    return [inDate.getFullYear(), "-", month, "-", date, " ", hour, ":", minute, ":", second].join('');
}
/**
 * 取得目前的yyMMdd日期時間
 * @param {separator} separator 組成日期字串的間隔字元
 * @returns {string} 組成的日期字串
 */
function GetyyyyMMddNow(separator) {
    if (separator === undefined)
        separator = '';
    var currentdate = new Date();
    var year = currentdate.getFullYear();
    var month = currentdate.getMonth() + 1;
    if (month < 10)
        month = "0" + month;
    var date = currentdate.getDate();
    if (date < 10)
        date = "0" + date;
    return [year, month, date].join(separator);
}

/**
 * 將yyyy-MM-dd格式轉成yyyyMMdd
 * @param {string} date yyyy-MM-dd 格式
 * @returns {string} 組成的日期字串
 */
function ConvertToyyyyMMdd(date) {
    return date.replaceAll('-', '');
}

/**
 * 將yyyyMMdd格式轉成yyyy-MM-dd
 * @param {string} yyyyMMdd格式
 */
function ConvertyyyyMMddWithHyphen(s) {
    return s.replace(/(\d{4})(\d{2})(\d{2})/g, '$1-$2-$3');
}

/**
 * 從 Select 元件中透過傳入的 值 找到其 顯示文字
 * @param {object} $ddl 傳入的 select
 * @param {string} value 傳入的值
 * @returns {string} select 的 text
 */
function GetTextFromSelectByValue($ddl, value) {
    var text = "";
    $ddl.find('option').each(function (e) {
        if ($(this).val().trim() === value) {
            text = $(this).text();
            return false;
        }
    });
    return text;
}
/**
 * Ajax
 * @param {RequestAct} requestAct
 * @param {RequestType} requestType
 * @param {string} code
 * @param {object} $files
 * @returns {string} 回傳結果
 */
function Ajax(requestAct, requestType, code, $files) {

    var res = '',
        form_data = new FormData();
    form_data.append("r", requestAct);
    form_data.append('t', requestType);
    form_data.append('c', code);
    if ($files !== undefined) {
        for (var i = 0; i < $files.length; i++) {
            form_data.append('files[]', $files[i]);
        }
    }
    form_data.append('csrfmiddlewaretoken', $('input[name="csrfmiddlewaretoken"]').val());
    $.ajax({
        url: "/Handler_ajax/",
        dataType: 'json', // what to expect back from server
        type: "post",
        async: false,
        cache: false,
        contentType: false,
        processData: false,
        data: form_data,
        success: function (msg) {
            res = msg;
        },
        beforeSend: function () { },
        complete: function () { },
        error: function (xhr, ajaxOptions, thrownError) {
            Alert(xhr.status);
            Alert(thrownError);
        }
    });
    return res;
}

/**
 * 依據輸入的關鍵字，從$container裡面依className、name、id找到元件
 * @param {any} $container
 * @param {any} propertyName
 * @returns {object} 找到的Jquery物件
 */
function getElementByKeyword($container, propertyName) {
    console.log("propertyName = " + propertyName);
    var $target = $container.find('.' + propertyName);
    if ($target.length > 0) {
        console.log("found by class");
        return $target;
    } else {
        $target = $container.find('[name=' + propertyName + ']');
        if ($target.length > 0) {
            console.log("found by name");
            return $target;
        } else {
            $target = $container.find('#' + propertyName);
            if ($target.length > 0) {
                console.log("found by name");
                return $target;
            } else {
                console.log("not found");
                return $target;
            }
        }
    }
}

/**
 * 將 input 的內容 填入 obj 並回傳
 * @param {any} profile 定義在 dm-objects.js 的物件
 * @param {any} $fromContainer 使用Jquery搜尋的輸入項父容器
 * @returns {any} obj 定義在 dm-objects.js 的物件
 */
function GetProfileFromInputs(profile, $fromContainer) {

    $.each(Object.keys(profile), function (i, propertyName) {
        var $obj = getElementByKeyword($fromContainer, propertyName);
        if ($obj.length === 0)
            return true;

        if ($obj.length > 1)
            $obj = $obj[0];

        var value;
        switch ($obj.prop('nodeName')) {
            case "SPAN":
                value = $obj.text().trim();
                break;
            case "INPUT":
                value = $obj.val().trim();
                if ($obj.prop('type') === "number") {
                    if (value.length === 0 || parseFloat(value) < 0 || isNaN(value))
                        value = 0;
                }
                if ($obj.prop('type') === "tel")
                    value = value.replace('_', '');
                if ($obj.prop('type') === "color")
                    value = $obj.spectrum("get").toHexString();
                break;
            case "SELECT":
            case "TEXTAREA":
                value = $obj.val();
                break;
        }
        profile[propertyName] = value;
    });
    return profile;
}
/**
 * 將來源的 span 的文字內容填到 obj物件 跟 text，並回傳obj (使用有標準格式，請參考ucListCustomerBoard.ascx)
 * @param {any} profile 定義在 dm-objects.js 的物件
 * @param {any} $spanContainer span物件的父容器，例如$tr
 * @param {any} $InputContainer inputs 的父容器，例如 inputForm
 * @returns {any} obj 定義在 dm-objects.js 的物件
 */
function SetObjectAndTextValueByNameFromSpan(profile, $spanContainer, $InputContainer) {
    var props = Object.keys(profile);
    $.each(Object.keys(profile), function (i, propertyName) {
        var $spanObj = getElementByKeyword($spanContainer, propertyName);
        if ($spanObj.length === 0)
            return true;

        var value = $spanObj.text().trim();
        profile[propertyName] = value;
        var $inputObj = getElementByKeyword($InputContainer, propertyName);
        if ($inputObj.length > 0) {
            switch ($inputObj.prop('nodeName')) {
                case "SPAN":
                    $inputObj.text(value);
                    break;
                case "INPUT":
                    $inputObj.val(value);
                    if ($inputObj.prop('type') === "number") {
                        if (value.length === 0 || parseFloat(value) < 0 || isNaN(value))
                            value = 0;
                    }
                    if ($inputObj.prop('type') === "tel")
                        value = value.replace('_', '');
                    if ($inputObj.prop('type') === "color")
                        value = $inputObj.spectrum("get").toHexString();
                    break;
                case "SELECT":
                case "TEXTAREA":
                    value = $inputObj.val();
                    break;
            }
        }
    });
    return profile;
}
/**
 * 將 input 的內容 填入 obj 並回傳 (使用有標準格式，請參考ucListCustomerBoard.ascx)
 * @param {any} obj 定義在 dm-objects.js 的物件
 * @param {any} $inputs 使用Jquery搜尋的輸入項物件(們)
 * @returns {any} obj 定義在 dm-objects.js 的物件
 */
function GetObjectValueFromInputByName(obj, $inputs) {
    var props = Object.keys(obj);
    $inputs.each(function (e) {
        var name = $(this).prop('name');
        if (props.includes(name)) {
            var value = $(this).val().trim();
            if ($(this).prop('type') === "number") {
                if (value.length === 0 || parseFloat(value) < 0 || isNaN(value))
                    value = 0;
            }
            if ($(this).prop('type') === "tel")
                value = value.replace('_', '');
            obj[name] = value;
        }
    });
    return obj;
}
/**
 * 將物件內容佈署到 $span 物件中
 * @param {any} profile 物件
 * @param {any} $toInputContainer span的 物件陣列
 * @returns {any} obj 定義在 dm-objects.js 的物件
 */
function SetInputValueFromObject(profile, $toInputContainer) {

    $.each(Object.keys(profile), function (i, propertyName) {
        var $obj = getElementByKeyword($toInputContainer, propertyName);
        if ($obj.length === 0)
            return true;

        var value = profile[propertyName];
        switch ($obj.prop('nodeName')) {
            case "SPAN":
                $obj.text(value);
                break;
            case "INPUT":
            case "TEXTAREA":
                $obj.val(value);
                break;
            case "SELECT":
                $obj.find('option').each(function () {
                    if ($(this).val() === value.toString()) {
                        $obj[0].selectedIndex = $(this).index();
                        return false;
                    }
                })
                break;
        }
    });
}
/**
 * 將物件內容佈署到 $span 物件中
 * @param {any} obj 物件
 * @param {any} $span span的 物件陣列
 * @returns {any} obj 定義在 dm-objects.js 的物件
 */
function SetSpanTextFromObject(obj, $span) {
    var props = Object.keys(obj);
    $span.each(function (e) {
        var name = $(this).prop('class').replace('displaynone', '').replace('dm-cutWordTwo', '').replace('dm-cutWord', '').trim();
        if (props.includes(name)) {
            $(this).text(obj[name]);
            return;
        }
    });
    return obj;
}

/**
 * 依據螢幕寬、高以及影片$videoPlayer取得播放器最適寬、高
 * @param {object} $videoPlayer
 */
function GetPlayerWidthHeight($videoPlayer) {
    return GetPlayerScreenWidthHeight($videoPlayer[0].videoWidth, $videoPlayer[0].videoHeight);
    // 取得處使用 var { screenWidth, screenHeight } = GetPlayerWidthHeight($videoPlayer);
}
/**
 * 依據螢幕寬、高以及影片$videoPlayer取得播放器最適寬、高
 * @param {int} reqWidth
 * @param {int} reqHeight
 */
function GetPlayerScreenWidthHeight(reqWidth, reqHeight) {
    var screenRatio = reqWidth / reqHeight,
        winWidth = $(window).width(),
        winHeight = $(window).height(),
        screenHeight, screenWidth;
    if (screenRatio > 1) { // 影片橫向
        screenWidth = Math.min(winWidth, Math.min(800, reqWidth));
        screenHeight = screenWidth / screenRatio;
        if (screenHeight > winHeight) { // 高度仍比螢幕高
            screenHeight = winHeight;
            screenWidth = screenHeight * screenRatio;
        }
    } else { // 影片直向
        screenHeight = Math.min(winHeight, Math.min(450, reqHeight));
        screenWidth = screenHeight * screenRatio;
        if (screenWidth > winWidth) { // 寬度仍比螢幕寬
            screenWidth = winWidth;
            screenHeight = screenWidth / screenRatio;
        }
    }
    return { screenWidth, screenHeight };
    // 取得處使用 var { screenWidth, screenHeight } = GetPlayerScreenWidthHeight(reqWidth, reqHeight);
}
