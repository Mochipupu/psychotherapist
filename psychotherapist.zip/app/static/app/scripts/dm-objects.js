﻿/**
 * A pair of Key and Value
 * @param {any} key 鍵名
 * @param {any} value 鍵值
 */
function KeyValue(key, value) {
    this.Key = key;
    this.Value = value;
}

/** Requested action in AjaxObj */
var RequestAct = {
    None: 0,
    Insert: 1,
    Update: 2,
    Delete: 3,
    Select: 4,
    Close: 5,
}

/** Requested object type in AjaxObj */
var RequestType = {
    None: 0,
    KeepAlive: 1,
    Login: 2,
    Logout: 3,
    Account: 4,
    BSRS: 5,
    Depression: 6,
    Chat: 7,
    MatchMaking: 8,
}

/**
 * 傳遞參數
 * @param {any} obj 傳入經 Json.Parse 後的物件
 */
function RequestParameters(obj) {
    this.Act = RequestAct.None;
    this.Fid = 0;
    this.Keyword = "";
    this.PageIndex = 1;
    this.Recipe = "";
    this.Source = JSON.stringify([]);
    this.TypeCode = "";

    for (var prop in obj) this[prop] = obj[prop];
}
