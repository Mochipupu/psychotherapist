﻿$(function () {
    bindDefaultPopupFormEvents();
    WrapperAdjust();
    $(window).resize(function (e) { WrapperAdjust(); });
});

function bindDefaultPopupFormEvents() {

    var $hideDialogs = $('.keep .dm-dialogBox');
    if ($hideDialogs.length > 0) {
        SetPopupFormSizePosition($hideDialogs, 600);
        $(window).resize(function (e) {
            SetPopupFormSizePosition($hideDialogs, 600);
            WrapperAdjust();
        });
    }
    // 偵測 popform 輸入 Esc 送出
    $('body').on('keydown', '.dm-dialogOverlay.keep', function (e) {
        var keycode = (e.keyCode ? e.keyCode : (e.which ? e.which : e.charCode));
        if (keycode === 27) {
            ConfirmCloseForm($(this).find('.dm-dialogButtons .dm-btnCancel'));
            return false;
        }
    });
    // 偵測 popform 輸入 Enter 送出
    $('.dm-dialogOverlay.keep').on('click', 'a.recall', function (e) {
        var sizeType = $(this).data('value');
        if (sizeType === "0") {
            SetPopupFormSizePosition($(this).closest('.dm-dialogBox'), 600);
            $(this).data('value', '1');
        } else {
            SetPopupFormSizePosition($(this).closest('.dm-dialogBox'), $(window).width() - 40, "10px", $(window).height() - 30);
            $(this).data('value', '0');
        }
    });
    // 偵測 popform 輸入 Esc 送出
    $('.dm-dialogOverlay.keep').on('click', 'a.close', function (e) {
        var $container = $(this).closest('.dm-dialogOverlay.keep');
        var $btnCancel = $container.find('.dm-dialogButtons .dm-btnCancel');
        if ($container.find('.dm-dialogButtons a').length === 1)
            $btnCancel.trigger('click');
        else
            ConfirmCloseForm($btnCancel);
    });
}

function bindHelperEvents() {

    if ($('.manual').length > 0) {
        var $manual = $('.manual');
        $('.helperList .dm-dialogContent h2').remove();
        var $manualContainer = $('.ulTerms'),
            $subManualContainer = $('.ulSubTerms');
        $manual.each(function (e) {
            var $li = $(["<li><span class='dm-circle'></span><a href='javascript:void(0)' title='", $(this).data('name'), "'>", $(this).data('name'), "</a></li>"].join(''));
            $li.appendTo(($(this).data('value') === 0) ? $manualContainer : $subManualContainer);
        });
        $('body').on('click', '.ulTerms li, .ulSubTerms li', function (e) {
            var $manual = $('.manual');
            if ($(this).hasClass('active')) {
                $('.formAddress').slideUp();
                $(this).removeClass('active');
            } else {
                $('.ulTerms li, .ulSubTerms li').removeClass('active');
                $(this).addClass('active');
                var name = $(this).find('a').prop('title');
                $manual.each(function (e) {
                    if ($(this).data('name') === name) {
                        $('.formAddress').html($(this).html().trim());
                        $('.formAddress').slideDown();
                        return false;
                    }
                });
            }
        });
    }
}

/**
 * 關閉跳出視窗
 * @param {any} $hideBtn 視窗中的取消按鈕(不同跳出視窗有不同的關閉方式)
 */
function ClosePopupForm($hideBtn) {
    $hideBtn.trigger('click');
}

/**
 * 確認關閉跳出視窗
 * @param {any} $hideBtn 視窗中的取消按鈕(不同跳出視窗有不同的關閉方式)
 */
function ConfirmCloseForm($hideBtn) {
    $.confirm({
        'message': '是否要關閉視窗？',
        'buttons': {
            '確定': { 'class': 'blue', 'action': function () { ClosePopupForm($hideBtn); } },
            '取消': { 'class': 'gray', 'action': function () { return false; } }
        }
    });
}
/** 調整頁長過短的foot最下方空白問題 */
function WrapperAdjust() {
    var wrapperHeight = $(window).height() - $('#header').outerHeight() - $('#divFootAbout').outerHeight();
    $('#wrapper').css({ "height": wrapperHeight + "px", "max-height": wrapperHeight + "px" });
}
/** 凍結背景畫面 */
function SetScreenFreeze() {
    $('body').addClass('stop-scrolling');
    $('body').bind('touchmove', function (e) { e.preventDefault() });
}
/** 解除凍結背景畫面 */
function SetScreenDefreeze() {
    $('body').removeClass('stop-scrolling');
    $('body').unbind('touchmove');
}
/** 禁止返回上一頁 */
function ForbidGetBack() {
    window.history.forward(1);
}
/** 保持登入網路連線 */
function KeepSessionAlive() {
    var res = Ajax(RequestAct.Select, RequestType.KeepAlive, "");
}
/**
 * 載入日期選取器
 * @param {any} $obj 要綁定的物件
 */
function LoadDatePicker($obj, year) {
    if (isMobile())
        $obj.scroller({ theme: 'android-ics', lang: 'zh_CN', preset: 'date', });
    else {
        if (year === undefined)
            $obj.datepicker({ dateFormat: 'yy-mm-dd', showOn: 'focus', changeYear: true, changeMonth: true, minDate: '-100y', maxDate: '100y' });
        else
            $obj.datepicker({ dateFormat: 'yy-mm-dd', showOn: 'focus', changeYear: true, changeMonth: true, minDate: '-100y', maxDate: '100y' });
        $obj.inputmask({ "mask": "9999-99-99" });
    }

    //$obj.scroller({
    //    preset: 'date',
    //    //theme: 'ios',
    //    theme: 'android-ics',
    //    lang: 'zh_CN',
    //});
}
/**
 * 載入日期選取器
 * @param {any} $obj 要綁定的物件
 */
function LoadTimePicker($obj) {
    $obj.scroller({
        preset: 'time',
        theme: 'android-ics',
        //display: 'bottom',
        //mode: 'scroller',
        lang: 'zh_CN',
    });
}

/**
 * 載入日期選取器
 * @param {any} $obj 要綁定的物件
 */
function LoadDateTimePicker($obj) {
    $obj.scroller({
        preset: 'datetime',
        theme: 'android-ics',
        lang: 'zh_CN',
    });
}

/** 設定元件 Focus */
(function ($) {
    jQuery.fn.setfocus = function () {
        return this.each(function () {
            var dom = this;
            setTimeout(function () {
                try { dom.focus(); } catch (e) { console.log(e); }
            }, 0);
        });
    };
})(jQuery);
/** 初始化左方工具列(記得掛載 slimscroll.js) */
function SetupLeftBar() {
    var windowHeight = $(window).height();
    $('.dm-leftBar').css({ 'height': windowHeight + 'px' });
    var bodyHeight = windowHeight - $('.leftbar-Logo').height();
    $(".leftbar-body").css({ 'height': bodyHeight + 'px' });
    $(".slimscrollleft").css({ 'height': bodyHeight + 'px' });

    $(".slimscrollleft").slimScroll({
        height: bodyHeight + "px",
        //height: "auto",
        size: "10px",
        color: "#9ea5ab",
    });
}
/**
 * 以 Post 方式傳遞新網頁
 * @param {string} pageName 網頁名稱(不包含.html)
 * @param {string} params 參數JSON化字串
 * @param {string} target 是否此網頁開啟(_self)或另開新網頁(_blank)
 */
function SubmitPostFormWithPara(pageName, params, target) {

    if (pageName === undefined || pageName.length === 0)
        pageName = '/home/';
    if ((params === undefined || params.length === 0) && $('#hfParas').length > 0)
        params = $('#hfParas').val().trim();
    if (target === undefined || target.length === 0) {
        target = "_self";
    }

    var form = document.createElement("form");
    form.setAttribute("method", "post");
    form.setAttribute("action", pageName);
    form.setAttribute("target", target);

    var hiddenField = document.createElement("input");
    hiddenField.setAttribute("type", "hidden");
    hiddenField.setAttribute("name", "r");
    hiddenField.setAttribute("value", params);
    form.appendChild(hiddenField);

    hiddenField = document.createElement("input");
    hiddenField.setAttribute("type", "hidden");
    hiddenField.setAttribute("name", 'csrfmiddlewaretoken');
    hiddenField.setAttribute("value", $('input[name="csrfmiddlewaretoken"]').val());
    form.appendChild(hiddenField);
    document.body.appendChild(form);
    form.submit();
    form.remove();
}