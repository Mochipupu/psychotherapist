﻿/** login */
var login = (function () {
    var that = {};
    that.init = function () {

        $("#account, #password").keypress(function (e) {
            code = (e.keyCode ? e.keyCode : e.which);
            if (code == 13) {
                $('.jLogin').trigger('click');
            }
        });

        $('.jLogin').click(function (e) {
            var account = $('#account').val().trim(),
                password = $('#password').val().trim();
            if (account.length === 0) {
                Alert("請輸入工號");
                return false;
            }
            if (password.length === 0) {
                Alert("請輸入密碼");
                return false;
            }

            var res = Ajax(RequestAct.Select, RequestType.Login, JSON.stringify(new KeyValue(account, password)));
            if (res.content.length === 0) {
                AlertGet("歡迎來到『AI療心實驗室』", "/home");
            } else {
                Alert(res.content);
            }
        });
    };
    return that;
})();


function questionnaire(requestType) {

    if ($("#hf").val().trim().length > 0) {
        var content = JSON.parse($("#hf").val().trim());
        var $panels = $(".panels");
        for (var i = 0; i < $panels.length; i++) {
            if (content.length > i) {
                $panels.eq(i).find('a').eq(content[i]).addClass("active");
            } else {
                break;
            }
        }
    }

    $(".panels a").click(function (e) {
        var $a = $(this).closest("ul").find("a");
        $a.removeClass("active");
        $(this).addClass("active");
    });

    $('.jNext').click(function (e) {
        var $pnl = $(".panels:visible"),
            $panels = $(".panels");
        $('.liPrevious').show();
        if ($pnl.length > 0) {
            var index = $pnl.data('index');
            if (index === $panels.length - 1) {
                $('.liNext').hide();
                $('.liSend').show();
            }
            $panels.eq(index - 1).hide();
            $panels.eq(index).fadeIn();
        }
    });

    $('.jPrevious').click(function (e) {
        var $pnl = $(".panels:visible"),
            $panels = $(".panels");
        $('.liNext').show();
        $('.liSend').hide();
        if ($pnl.length > 0) {
            var index = parseInt($pnl.data('index'));
            if (index == 2) {
                $('.liPrevious').hide();
            }
            $panels.eq(index - 1).hide();
            $panels.eq(index - 2).fadeIn();
        }
    });

    $('.jSend').click(function (e) {
        var content = []
        var $pnl = $(".panels:visible"),
            $panels = $(".panels"),
            chkSum = true;
        for (var i = 0; i < $panels.length; i++) {
            var $option = $panels.eq(i).find("a.active");
            if ($option.length == 0) {
                chkSum = false;
                $pnl.hide();
                $panels.eq(i).fadeIn();
                Alert("請填寫完整");
                break;
            }
            content.push($option.data('value'));
        }
        if (chkSum) {
            $("#hf").val(JSON.stringify(content));
            $('.progress').show();
            setTimeout(function () {
                var res = Ajax(RequestAct.Insert, requestType, JSON.stringify(content));
                $('.progress').hide();
                setTimeout(function () {
                    if (res.msg === "OK") {
                        AlertGet("填寫完畢", "/home");
                    } else {
                        Alert(res.content);
                    }
                }, 200);
            }, 200);
        }
    });
}

/** BSRS */
var BSRS = (function () {
    var that = {};
    that.init = function () {
        questionnaire(RequestType.BSRS);
    };
    return that;
})();


/** depression */
var depression = (function () {
    var that = {};
    that.init = function () {
        questionnaire(RequestType.Depression);
    };
    return that;
})();


/** chat */
var chat = (function () {
    var that = {};
    that.init = function () {

        if ($('#hfChat0').val().trim().length > 0) {
            for (var i = 0; i < 4; i++) {
                var chat = $('#hfChat' + i).val().trim();
                if (chat.length === 0)
                    continue;
                var $user = (i % 2 === 0) ? $('.template .local').clone() : $('.template .remote').clone();
                $user.find('.text').text(chat);
                $('.dialogue').append($user);
            }
        }

        $('.dm-txt').keypress(function (e) {
            code = (e.keyCode ? e.keyCode : e.which);
            if (code == 13) {
                $('.jSend').trigger('click');
            }
        });

        $('.jSend').click(function (e) {
            var msg = $('.dm-txt').val().trim();
            if (msg.length === 0) {
                return false;
            }
            $('.progress').show();
            setTimeout(function () {
                var res = Ajax(RequestAct.Insert, RequestType.Chat, JSON.stringify(msg));
                $('.progress').hide();
                setTimeout(function () {
                    if (res.msg === "OK") {
                        var $user = $('.template .local').clone(),
                            $robot = $('.template .remote').clone();
                        $user.find('.text').text(msg);
                        $robot.find('.text').text(res.content);
                        $('.dialogue').append($user).append($robot);
                        $('.dm-txt').val('');
                    } else {
                        Alert(res.content);
                    }
                }, 200);
            }, 200);
        });


        function matchMaking() {
            var para = GetRequestParameters();
            para.TypeCode = "C300";
            SubmitPostFormWithPara('', JSON.stringify(para), "_self");
        }

        $('.jMatch').click(function (e) {
            var lackDialogue = $('.dialogue .user').length === 0,
                lackQuestionnaire = ($('#hfBSRS').val().trim().length + $('#hfDepression').val().trim().length) === 0;
            console.log(lackDialogue);
            console.log(lackQuestionnaire);
            if (lackDialogue && lackQuestionnaire) {
                Alert("請先輸入心理量表或是進行聊天");
                return false;
            } else if (!lackDialogue && lackQuestionnaire) {
                $.confirm({
                    'message': "目前尚缺心理問卷，準確率會較低，確認要繼續？",
                    'buttons': {
                        '確定': { 'class': 'blue', 'action': function () { matchMaking(); } },
                        '取消': { 'class': 'gray', 'action': function () { return false; } }
                    }
                });
            } else if (lackDialogue && !lackQuestionnaire) {
                $.confirm({
                    'message': "目前尚缺聊天內容，準確率會較低，確認要繼續？",
                    'buttons': {
                        '確定': { 'class': 'blue', 'action': function () { matchMaking(); } },
                        '取消': { 'class': 'gray', 'action': function () { return false; } }
                    }
                });
            } else {
                matchMaking();
            }
        });
    };
    return that;
})();



/** match */
var match = (function () {
    var that = {};
    that.init = function () {

        var arrScores = ($('#hfScores').val().trim().length > 0) ? JSON.parse($('#hfScores').val().trim()) : [];

        //if ($('#hfPsychotherapies').val().trim().length > 0
        //    && $('#hfScores').val().trim().length > 0) {
        //    var arrPsychotherapies = JSON.parse($('#hfPsychotherapies').val().trim());
        //    arrScores = JSON.parse($('#hfScores').val().trim());
        //    for (var i = 0; i < arrPsychotherapies.length; i++) {
        //        var psychotherapy = arrPsychotherapies[i];
        //        $psychotherapyContainer = $(".template .psychotherapy").clone();
        //        $psychotherapyContainer.find(".image").css("background", "url(../../images/" + psychotherapy.image + ") no-repeat");
        //        $psychotherapyContainer.find(".name").text(psychotherapy.Name);
        //        $psychotherapyContainer.find(".tel").text(psychotherapy.Tel);
        //        $psychotherapyContainer.find(".address").text(psychotherapy.Address);
        //        var $spanScores = $psychotherapyContainer.find(".expertise .score");
        //        for (var j = 0; j < psychotherapy.data.length; j++) {
        //            $spanScores.eq(j).text(psychotherapy.data[j]);
        //        }
        //        $psychotherapyContainer.data("value", JSON.stringify(psychotherapy.data));
        //        $('.psychotherapyContainer').append($psychotherapyContainer);
        //    }
        //}

        var ctx = $("#radarChart")[0].getContext('2d');
        var data = {
            labels: [
                '自我探索',
                '工作職涯',
                '人際互動',
                '情緒壓力',
                '感情關係',
                '親職教養',
                '家庭關係',
                '性與性別',
            ],
            datasets: [{
                label: '您的評估分數',
                data: arrScores,
                fill: true,
                backgroundColor: 'rgba(255, 99, 132, 0.2)',
                borderColor: 'rgb(255, 99, 132)',
                pointBackgroundColor: 'rgb(255, 99, 132)',
                pointBorderColor: '#fff',
                pointHoverBackgroundColor: '#fff',
                pointHoverBorderColor: 'rgb(255, 99, 132)'
            }, {
                label: '諮商師專長',
                data: [28, 48, 40, 19, 96, 27, 100],
                fill: true,
                backgroundColor: 'rgba(54, 162, 235, 0.2)',
                borderColor: 'rgb(54, 162, 235)',
                pointBackgroundColor: 'rgb(54, 162, 235)',
                pointBorderColor: '#fff',
                pointHoverBackgroundColor: '#fff',
                pointHoverBorderColor: 'rgb(54, 162, 235)'
            }]
        };
        var config = {
            type: 'radar',
            data: data,
            options: {
                responsive: true, // 设置图表为响应式，根据屏幕窗口变化而变化
                maintainAspectRatio: false,// 保持图表原有比例
                elements: {
                    line: {
                        borderWidth: 1 // 设置线条宽度
                    }
                }
            }
        };
        var myChart = new Chart(ctx, config);
        $('body').on("click", '.psychotherapyContainer .psychotherapy', function (e) {
            myChart.destroy();
            data.datasets[1]["data"] = $(this).data('value');
            config["data"] = data;
            myChart = new Chart(ctx, config);
            $('.radarBoard').fadeIn();
        });

        $('.radarBoard').click(function (e) {
            $(this).fadeOut();
        });
    };
    return that;
})();