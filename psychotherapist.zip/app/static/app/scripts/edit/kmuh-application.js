﻿var arrReferralReasons = [], mother = {}, baby = {}, operation = {}, arrAmbulanceVitals = {}, report = {};

/**
 * 選單按下時，"其他"的"說明輸入"之顯示控制
 * @param {any} $this
 */
function AdditionalInputs($this) {
    var $i = $this.find('i'),
        $li = $('.' + $this.data('name'));
    if ($i.hasClass('far')) {
        $li.slideDown();
    } else {
        $li.slideUp();
    }
    $i.toggleClass('far fas');
}

/**
 * 取得具有"其他" 的選單的資料
 * @param {string} className
 * @param {Array} dictOptionClass
 * @returns string
 */
function GetOptionValuesWithOther(className, dictOptionClass = {}) {
    var arr = $('.' + className + ' i.fas').map(function (_, v) { return $(v).closest('a').data('value'); }).get();
    if (!dictOptionClass.hasOwnProperty('其他'))
        dictOptionClass['其他'] = className + 'Other';

    $.each(dictOptionClass, function (k, v) { // k: data-value in arr; v: txt class name
        var index = arr.indexOf(k);
        if (index >= 0) {
            var $txt = $('.txt' + v);
            if ($txt.length === 0) {
                return true;
            }   
            var str = $txt.val().trim();
            if (str.length === 0 || (!isNaN(str) && parseFloat(str) <= 0)) {
                arr.splice(index, 1);
            } else if (str.length > 0) {
                arr.splice(index + 1, 0, (!isNaN(str) && parseFloat(str) > 0) ? parseFloat(str) : str);
            }
            else {
                console.log("other state");
            }
        }
    });
    return arr.length === 0 ? "" : JSON.stringify(arr);
}

/**
 * 載入具有"其他" 的選單
 * @param {any} arrDicts
 */
function LoadSelectWithOther(arrDicts) {
    $.each(arrDicts, function (_, arrKeyValue) {
        var className = arrKeyValue["className"],
            strContent = arrKeyValue["strContent"],
            iClassName = arrKeyValue["iClassName"],
            arrKeyValue = arrKeyValue["arrKeyValue"];
        $('.' + className + ' a i').removeClass('fas ' + iClassName).addClass('far ' + iClassName);
        if (strContent.length > 0) { // 有值
            var $objs = $('.' + className + ' a'),
                arr = JSON.parse(strContent),
                arrtemp = [];
            for (var i = 0; i < arrKeyValue.length; i++) {
                var kv = arrKeyValue[i],
                    index = arr.indexOf(kv.Key);
                if (index >= 0) {
                    arrtemp = arr.slice(0, index);
                    var $input = $('.txt' + kv.Value);
                    if ($input.length == 0) {
                        console.log("無法找到" + className + '的 .txt' + kv.Value);
                        continue;
                    }
                    $input.val(arr[index + 1]);
                    $('.li' + kv.Value).show();
                    $('.' + className + ' .isOther.a' + kv.Value + ' i').removeClass('far ' + iClassName).addClass('fas ' + iClassName);
                } else {
                    arrtemp = arr;
                }
            }
            $.each((arrtemp.length === 0 ? arr : arrtemp), function (_, val) {
                $objs.each(function (e) {
                    if ($(this).data('value') === val) {
                        $(this).find('i').removeClass('far ' + iClassName).addClass('fas ' + iClassName);
                        return false;
                    }
                });
            });
        }
    });
}

function GetPanel1Data() {
    arrReferralReasons = [];
    $('.ulReferralReasons a').each(function (e) {
        if ($(this).find('i').hasClass('fas')) {
            arrReferralReasons.push($(this).data('value'));
        }
    });
    var referralReasonOther = $('.ReferralReasonOther').val().trim();
    if (arrReferralReasons.includes('其他')) {
        if (referralReasonOther.length === 0) {
            Alert("請輸入其他轉診原因");
            $('.ReferralReasonOther').setfocus();
            return [];
        } else {
            arrReferralReasons.push(referralReasonOther);
        }
    }
    return arrReferralReasons;
}

function GetPanel2Data() {
    mother.TID = $('#txtTID').val().trim();
    mother.Name = $('#txtName').val().trim();
    mother.BirthDate = $('#txtMontherBirthDate').val().trim();

    baby.Gender = $('#ddlBabyGender').val();
    baby.BirthDate = $('#txtBabyBirthDate').val().trim();
    baby.BirthTime = $('#txtBabyBirthTime').val().trim();

    var arrErrors = []
    if (!IsMeetTID(mother.TID))
        arrErrors.push('請輸入正確的身份證字號');
    if (mother.Name.length === 0)
        arrErrors.push('請輸入母親姓名');
    if (!IsValidDate(mother.BirthDate))
        arrErrors.push('母親生日輸入有誤');

    if (baby.Gender == "0")
        arrErrors.push('請選擇嬰兒性別');
    if (!IsValidDate(baby.BirthDate))
        arrErrors.push('嬰兒出生日期輸入有誤');
    if (!IsValidTime(baby.BirthTime))
        arrErrors.push('嬰兒出生時間輸入有誤');
    return arrErrors;
}

function GetPanel3Data() {
    var arrErrors = [];
    // Mother
    $.each({ "Gravida": "Gravida", "Para": "Para" }, function (k, v) {
        mother[k] = $('#txt' + k).val().trim();
        if (mother[k].length > 0 && isNaN(mother[k]))
            arrErrors.push(v + "輸入有誤");
    });
    $.each({ "BloodType": {}, "RHType": {}, "Antibody": {}, "BloodTest": {}, "PastHistory": {} }, function (className, d) {
        mother[className] = GetOptionValuesWithOther(className, d);
    });
    // Baby
    baby["EstimatedDueDate"] = $('#txtEstimatedDueDate').val().trim();
    if (baby["EstimatedDueDate"].length > 0 && !IsValidDate(baby["EstimatedDueDate"]))
        arrErrors.push("預產日期輸入有誤");

    var d = {
        // 治療
        "Treat": { "有": "Treat" },
        // 處置方式
        "Handle": {},
        // 餵食
        "Feed": { "有": "FeedOther" },
    };
    $.each(d, function (className, dictOptionClass) {
        baby[className] = GetOptionValuesWithOther(className, dictOptionClass);
    });

    d = {
        "PregnantWeek": "懷孕週數",
        "BeforeTemperature": "欲轉診時體溫",
        "BeforePulse": "欲轉診時脈搏",
        "BeforeRespiration": "欲轉診時呼吸",
        "BeforeSpO2": "欲轉診時SpO<sub>2</sub>",
        "ApgarScore1": "Apgar分數1分鐘",
        "ApgarScore5": "Apgar分數5分鐘",
        "ApgarScore10": "Apgar分數10分鐘",
    };
    var dDateTime = { "BeforeAt": "欲轉診時量測時間", };
    if ($('.aTreat i').hasClass('fas')) {
        d = Object.assign({}, d, {
            "TreatTemperature": "治療後體溫",
            "TreatPulse": "治療後脈搏",
            "TreatRespiration": "治療後呼吸",
            "TreatSpO2": "治療後SpO<sub>2</sub>",
        });
        dDateTime = Object.assign({}, dDateTime, { "TreatAt": "治療後量測時間", });
    } else {
        $.each(["TreatTemperature", "TreatPulse", "TreatRespiration", "TreatSpO2", "TreatAt"], function (_, v) {
            baby[v] = "";
        });
    }
    $.each(d, function (k, v) {
        baby[k] = $('#txt' + k).val().trim();
        if (baby[k].length > 0 && isNaN(baby[k]))
            arrErrors.push(v + "輸入有誤");
    });
    $.each(dDateTime, function (k, v) {
        baby[k] = $('#txt' + k).val().trim();
        if (baby[k].length > 0 && !IsValidDateTime(baby[k]))
            arrErrors.push(v + "輸入有誤");
    });
    return arrErrors;
}

function GetPanel4Data() {

    var arrErrors = [];
    operation["RuptureMembranesDate"] = $('#txtRuptureMembranesDate').val().trim();
    if (operation["RuptureMembranesDate"].length > 0 && !IsValidDate(operation["RuptureMembranesDate"]))
        arrErrors.push("破水日期輸入有誤");
    operation["RuptureMembranesTime"] = $('#txtRuptureMembranesTime').val().trim();
    if (operation["RuptureMembranesTime"].length > 0 && !IsValidTime(operation["RuptureMembranesTime"]))
        arrErrors.push("破水時間輸入有誤");
    // 失血量
    operation["BloodLoss"] = $('#txtBloodLoss').val().trim();
    if (operation["BloodLoss"].length > 0) {
        operation["BloodLoss"] = parseInt(operation["BloodLoss"]);
    }

    var d_ = {
        // 羊水量
        "AmnioticFluid": {},
        // 嬰兒胎位
        "FetalPosition": {},
        // 生產方式
        "BirthType": {},
        // 麻醉方式
        "AnesthesiaType": {},
        // 妊娠併發症
        "PregnancyComplications": {},
        // 生產情形
        "BirthProcess": { "臍繞頸": "NuchalCord" },
        // GBSTest
        "GBSTest": {},
        // 產前感冒
        "CatchCold": {},
        // 是否發燒
        "HaveFever": {},
        // 產婦用藥
        "Drugs": { "Steroid": "Steroid"},
    }

    $.each(d_, function (className, dictOptionClass) {
        operation[className] = GetOptionValuesWithOther(className, dictOptionClass);
    });
    // 嬰兒延遲啼哭
    baby["DOIC"] = GetOptionValuesWithOther("DOIC", { "有": "DOIC" });
    // 嬰兒身高體重等
    $.each({ "BirthWeight": "出生體重(公克)", "CurrentWeight": "目前體重(公克)", "BodyLength": "身體長度(公分)", "HeadLength": "頭圍長度(公分)", "ChestLength": "胸圍長度(公分)" }, function (k, v) {
        baby[k] = $('#txt' + k).val().trim();
        if (baby[k].trim().length > 0 && isNaN(baby[k]))
            arrErrors.push(v + "輸入有誤");
    });
    // 轉診單位的醫護
    report["ApplicationPhysicianID"] = $('#ddlApplicationPhysicianID').val();
    report["ApplicationNurseID"] = $('#ddlApplicationNurseID').val();

    // 高醫救護車醫護與主治醫師
    if ($('#ddlAmbulancePhysicianID').length > 0) {
        report["AmbulancePhysicianID"] = $('#ddlAmbulancePhysicianID').val();
        report["AmbulanceNurseID"] = $('#ddlAmbulanceNurseID').val();
        report["AttendingPhysicianID"] = $('#ddlAttendingPhysicianID').val();
    }

    // 救護車量測生命體徵
    var $divAmbulanceVitals = $('.jInsertVital').closest('fieldset').find('.inputForm:not(".divVitalSignsTemplate")');
    if ($divAmbulanceVitals.length > 0) {
        arrAmbulanceVitals = [];
        d_ = {
            "Temperature": "救護車上量測體溫",
            "Pulse": "救護車上量測脈搏",
            "Respiration": "救護車上量測呼吸",
            "SpO2": "救護車上量測SpO<sub>2</sub>",
        };
        for (var i = 0; i < $divAmbulanceVitals.length; i++) {
            var $divAmbulanceVital = $divAmbulanceVitals.eq(i),
                d_AmbulanceVitals = new AmbulanceVitals();
            $.each(d_, function (k, v) {
                d_AmbulanceVitals[k] = $divAmbulanceVital.find('.Ambulance' + k).val().trim();
                if (d_AmbulanceVitals[k].length > 0 && isNaN(d_AmbulanceVitals[k]))
                    arrErrors.push(["第", i + 1, "筆的", v, "輸入有誤"].join(''));
            });
            d_AmbulanceVitals.At = $divAmbulanceVital.find('.AmbulanceAt').val().trim();
            if (d_AmbulanceVitals.At.length > 0 && !IsValidDateTime(d_AmbulanceVitals.At))
                arrErrors.push(["第", i + 1, "筆的救護車上量測時間輸入有誤"].join(''));

            d_AmbulanceVitals.BloodPressure = $divAmbulanceVital.find('.AmbulanceBloodPressure').val().trim();
            if (d_AmbulanceVitals.BloodPressure.length > 0) {
                var indexOfSeparator = d_AmbulanceVitals.BloodPressure.indexOf('/');
                if (indexOfSeparator < 0) {
                    arrErrors.push(["第", i + 1, "筆的救護車上量測血壓需有分隔符號「/」"].join(''));
                } else {
                    var temp = d_AmbulanceVitals.BloodPressure.split('/');
                    if (temp.length !== 2) {
                        arrErrors.push(["第", i + 1, "筆的救護車上量測血壓輸入有誤"].join(''));
                    } else {
                        var h = temp[0].trim(), l = temp[1].trim();
                        if (h.length === 0 || isNaN(h) || l.length === 0 || isNaN(l)) {
                            arrErrors.push(["第", i + 1, "筆的救護車上量測血壓輸入有誤"].join(''));
                        }
                    }
                }
            }
            d_AmbulanceVitals["ReportID"] = report["fid"];
            d_AmbulanceVitals["fid"] = $divAmbulanceVital.data('key');
            arrAmbulanceVitals.push(d_AmbulanceVitals);
        }
    }
    // 轉入治療單位
    var $ddlTherapyUnit = $('#ddlTherapyUnit');
    if ($ddlTherapyUnit.length > 0) {
        if ($ddlTherapyUnit.val() === "0") {
            report["TherapyUnit"] = "";
        } else if ($ddlTherapyUnit.val() === "其他") {
            report["TherapyUnit"] = $('#txtTherapyUnitOther').val().trim();
            if (report["TherapyUnit"].length === 0) {
                arrErrors.push("轉入治療單位選擇「其他」時輸入有誤");
            }
        } else {
            report["TherapyUnit"] = $('#ddlTherapyUnit').val();
        }
    }

    return arrErrors;
}

/** 載入轉診申請 */
function LoadApplicationData() {

    // pandel 1
    function setPanel1Data() {
        var $objs = $('.ulReferralReasons li a');
        $.each(arrReferralReasons, function (i, reason) {
            $objs.each(function (e) {
                if ($(this).data('value') === reason) {
                    $(this).find('i').toggleClass('far fas');
                    return false;
                }
            });
        });
        if (arrReferralReasons.includes('其他')) {
            $('.ReferralReasonOther').val(arrReferralReasons[arrReferralReasons.length - 1]);
            $('.liReferralReasonOther').show();
        }
    }

    // pandel 2
    function setPanel2Data() {
        $.each(["TID", "Name", "Gravida", "Para"], function (_, v) {
            $('#txt' + v).val(mother[v]);
        });
        var arrTemp = ["BeforeTemperature", "BeforePulse", "BeforeRespiration", "BeforeSpO2", "BeforeAt", "BirthWeight", "CurrentWeight", "BodyLength", "HeadLength", "ChestLength", "ApgarScore1", "ApgarScore5", "ApgarScore10"];
        if (baby["Treat"].indexOf("有") >= 0) {
            arrTemp = arrTemp.concat(["TreatTemperature", "TreatPulse", "TreatRespiration", "TreatSpO2", "TreatAt"])
        }
        $.each(arrTemp, function (_, v) {
            $('#txt' + v).val(baby[v]);
        });
        $.each(["RuptureMembranesDate", "RuptureMembranesTime", "BloodLoss"], function (_, v) {
            $('#txt' + v).val(operation[v]);
        });
        $('#txtMontherBirthDate').val(mother["BirthDate"]);
        $('#ddlBabyGender').val(baby["Gender"]);
        $('#txtBabyBirthDate').val(baby["BirthDate"]);
        $('#txtBabyBirthTime').val(baby["BirthTime"]);
    }
    
    // panel 3~4
    function setPanel34Data() {

        $.each(["PregnantWeek", "EstimatedDueDate"], function (_, v) {
            $('#txt' + v).val(baby[v]);
        });
        var arrTemp = [
            // panel 3
            { "className": "Treat", "strContent": baby["Treat"].trim(), "iClassName": 'fa-circle', "arrKeyValue": [new KeyValue("有", "Treat")] },
            { "className": "Handle", "strContent": baby["Handle"].trim(), "iClassName": 'fa-square', "arrKeyValue": [new KeyValue("其他", "HandleOther")] },
            { "className": "Feed", "strContent": baby["Feed"].trim(), "iClassName": 'fa-circle', "arrKeyValue": [new KeyValue("有", "FeedOther")] },

            { "className": "BloodType", "strContent": mother["BloodType"].trim(), "iClassName": 'fa-circle', "arrKeyValue": [] },
            { "className": "RHType", "strContent": mother["RHType"].trim(), "iClassName": 'fa-circle', "arrKeyValue": [] },
            { "className": "Antibody", "strContent": mother["Antibody"].trim(), "iClassName": 'fa-square', "arrKeyValue": [] },
            { "className": "BloodTest", "strContent": mother["BloodTest"].trim(), "iClassName": 'fa-circle', "arrKeyValue": [] },
            { "className": "PastHistory", "strContent": mother["PastHistory"].trim(), "iClassName": 'fa-square', "arrKeyValue": [new KeyValue("其他", "PastHistoryOther")] },
            // panel 4
            { "className": "AmnioticFluid", "strContent": operation["AmnioticFluid"].trim(), "iClassName": 'fa-square', "arrKeyValue": [new KeyValue("其他", "AmnioticFluidOther")] },
            { "className": "FetalPosition", "strContent": operation["FetalPosition"].trim(), "iClassName": 'fa-circle', "arrKeyValue": [new KeyValue("其他", "FetalPositionOther")] },
            { "className": "BirthType", "strContent": operation["BirthType"].trim(), "iClassName": 'fa-circle', "arrKeyValue": [] },
            { "className": "AnesthesiaType", "strContent": operation["AnesthesiaType"].trim(), "iClassName": 'fa-circle', "arrKeyValue": [] },
            { "className": "BirthProcess", "strContent": operation["BirthProcess"].trim(), "iClassName": 'fa-square', "arrKeyValue": [new KeyValue("其他", "BirthProcessOther"), new KeyValue("臍繞頸", "NuchalCord")] },
            { "className": "DOIC", "strContent": baby["DOIC"].trim(), "iClassName": 'fa-circle', "arrKeyValue": [new KeyValue("有", "DOIC")] },
            { "className": "GBSTest", "strContent": operation["GBSTest"].trim(), "iClassName": 'fa-circle', "arrKeyValue": [] },
            { "className": "CatchCold", "strContent": operation["CatchCold"].trim(), "iClassName": 'fa-circle', "arrKeyValue": [] },
            { "className": "HaveFever", "strContent": operation["HaveFever"].trim(), "iClassName": 'fa-circle', "arrKeyValue": [] },
            { "className": "PregnancyComplications", "strContent": operation["PregnancyComplications"].trim(), "iClassName": 'fa-square', "arrKeyValue": [new KeyValue("其他", "PregnancyComplicationsOther")] },
            { "className": "Drugs", "strContent": operation["Drugs"].trim(), "iClassName": 'fa-square', "arrKeyValue": [new KeyValue("其他", "DrugsOther"), new KeyValue("Steroid", "Steroid")] },
        ];
        LoadSelectWithOther(arrTemp);
        // 各題單選
        $('.BloodTest a i').removeClass('fas fa-circle').addClass('far fa-circle');
        if (mother["BloodTest"].trim().length > 0) {
            var $objs = $('.BloodTest li');
            $.each(JSON.parse(mother["BloodTest"].trim()), function (_, val) {
                $objs.each(function (e) {
                    var checked = false;
                    $(this).find('a').each(function (e) {
                        if ($(this).data('value') === val) {
                            $(this).find('i').removeClass('far fa-circle').addClass('fas fa-circle');
                            checked = true;
                            return false;
                        }
                    });
                    if (checked)
                        return false;
                });
            });
        }
    }

    function setKMUHData() {

        // 主治醫師、救護車隨車醫師與護理師
        $('#ddlApplicationPhysicianID').val(report["ApplicationPhysicianID"]);
        $('#ddlApplicationNurseID').val(report["ApplicationNurseID"]);
        if ($('#ddlAmbulancePhysicianID').length > 0) {
            $('#ddlAmbulancePhysicianID').val(report["AmbulancePhysicianID"]);
            $('#ddlAmbulanceNurseID').val(report["AmbulanceNurseID"]);
            $('#ddlAttendingPhysicianID').val(report["AttendingPhysicianID"]);
        }

        // 救護車上量測生命體徵
        var $insertVital = $('.jInsertVital');
        if ($insertVital.length > 0) {
            var $fieldset = $insertVital.closest('fieldset'),
                $template = $fieldset.find(".divVitalSignsTemplate");
            for (var i = arrAmbulanceVitals.length - 1; i >= 0; i--) {
                var $newInputform = $template.clone(),
                    index = i + 1,
                    ambulanceVitals = arrAmbulanceVitals[i];
                $newInputform.data('key', ambulanceVitals["fid"]);
                $newInputform.removeClass('divVitalSignsTemplate');
                $.each(["At", "Temperature", "Pulse", "Respiration", "SpO2", "BloodPressure"], function (i, v) {
                    var $obj = $newInputform.find('#txtAmbulance' + v);
                    $obj.prop('id', 'txtAmbulance' + v + index);
                    $obj.val(ambulanceVitals[v]);
                });
                $newInputform.find('#txtAmbulanceAt' + index).scroller({ preset: 'datetime', theme: 'android-ics', lang: 'zh_CN', });
                $newInputform.insertAfter($template).show();
            }
        }

        // 轉入治療單位
        var $ddlTherapyUnit = $('#ddlTherapyUnit');
        if ($ddlTherapyUnit.length > 0 && report["TherapyUnit"].trim().length > 0) {
            var arr = $ddlTherapyUnit.find('option').map(function (_, v) { return $(v).val(); }).get();
            if (arr.includes(report["TherapyUnit"].trim())) {
                $ddlTherapyUnit.val(report["TherapyUnit"].trim());
            } else {
                $ddlTherapyUnit.val("其他");
                $('#txtTherapyUnitOther').val(report["TherapyUnit"].trim());
                $('.divTherapyUnitOther').show();
            }
        }
    }

    setPanel1Data();
    setPanel2Data();
    setPanel34Data();
    setKMUHData();
}

/** 載入選單Click事件 */
function LoadSelectClickEvents() {

    $('.singleSelect a').click(function (e) {

        if ($(this).hasClass('isOther')) {
            AdditionalInputs($(this));
            if ($(this).find('i').hasClass('fas')) {
                $(this).closest('ul').find('li a i').removeClass('fas').addClass('far');
                $(this).find('i').removeClass('far').addClass('fas');
            }
            return false;
        }
        var $aIsOther = $(this).closest('ul').find('li a.isOther');
        if ($aIsOther.length > 0) {
            console.log("$aIsOther.data('name') = " + $aIsOther.data('name'));
            $('.' + $aIsOther.data('name')).slideUp();
        }
        var $i = $(this).find('i');
        if ($i.hasClass('fas')) {
            console.log("$i.hasClass('fas') = " + $i.hasClass('fas'));
            $i.removeClass('fas').addClass('far');
        } else {
            $(this).closest('ul').find('li a i').removeClass('fas').addClass('far');
            $i.removeClass('far').addClass('fas');
        }
        return false;
    });

    $('.multipleSelect a').click(function (e) {
        if ($(this).hasClass('isOther')) {
            AdditionalInputs($(this));
            return false;
        }
        $(this).find('i').toggleClass('far fas');
        return false;
    });

    $('.BloodTest li a').click(function (e) {
        var $i = $(this).find('i');
        if ($i.hasClass('fas')) {
            $i.removeClass('fas').addClass('far');
            return false;
        }
        $(this).closest('li').find('i').removeClass('fas').addClass('far');
        $i.removeClass('far').addClass('fas');
        return false;
    });
}

/** 載入按鈕事件*/
function LoadButtonClickEvents() {

    function loadMother(mother) {

        $('#txtTID').val(mother.TID);
        $('#txtName').val(mother.Name);
        $('#txtMontherBirthDate').val(mother.BirthDate);
        // 懷孕次數，不考慮最後是否有順利分娩
        $('#txtGravida').val(mother.Gravida);
        // 懷孕到可存活胎齡的次數(包括一般生產或是死產)
        $('#txtPara').val(mother.Para);
        var arrDicts = [
            // panel 3
            { "className": "BloodType", "strContent": mother["BloodType"].trim(), "iClassName": 'fa-circle', "arrKeyValue": [] },
            { "className": "RHType", "strContent": mother["RHType"].trim(), "iClassName": 'fa-circle', "arrKeyValue": [] },
            { "className": "Antibody", "strContent": mother["Antibody"].trim(), "iClassName": 'fa-square', "arrKeyValue": [] },
            { "className": "BloodTest", "strContent": mother["BloodTest"].trim(), "iClassName": 'fa-square', "arrKeyValue": [] },
            { "className": "PastHistory", "strContent": mother["PastHistory"].trim(), "iClassName": 'fa-square', "arrKeyValue": [new KeyValue("其他", "PastHistoryOther")] },
        ];
        LoadSelectWithOther(arrDicts);
    }

    function confirmAcceptApplication() {
        closeAllPopupForms();
        setTimeout(function () {
            var res = Ajax(RequestAct.Update, RequestType.Application, report.fid);
            if (res.msg === "OK") {
                Alert("已完成接收此案");
                $('.liConfirm').remove();
                $('.liAttend').removeClass('displaynone');
            } else {
                Alert(res.content);
            }
        }, 500);
    }

    function confirmAttendApplication(step) {
        closeAllPopupForms();
        setTimeout(function () {
            var res = Ajax(RequestAct.Insert, RequestType.Timestamps, [report.fid, step].join('^'));
            if (res.msg === "OK") {
                Alert("已登記出發時間");
                $('.liAttend').remove();
            } else {
                Alert(res.content);
            }
        }, 500);
    }

    function confirmCloseApplication() {
        closeAllPopupForms();
        setTimeout(function () {
            var res = Ajax(RequestAct.Close, RequestType.Application, report.fid);
            if (res.msg === "OK") {
                AlertRefresh("已完成結案");
            } else {
                Alert(res.content);
            }
        }, 500);
    }

    // 搜尋母親資料by身份證字號
    $('.jSearchTID').click(function (e) {
        var pid = $('#txtTID').val().trim();
        if (!IsMeetTID(pid)) {
            Alert('請輸入正確的身份證字號');
            return false;
        }
        var res = Ajax(RequestAct.Select, RequestType.Mother, pid);
        if (res.msg === "OK") {
            if (res.content.trim().length === 0) {
                Alert('查無產婦資料');
                return false;
            }
            mother = JSON.parse(res.content.trim());
            loadMother(mother);
        } else {
            closeAllPopupForms();
            setTimeout(function () {
                Alert(res.content);
            }, 500);
        }
    });
    // 後一步
    $('.jNext').click(function (e) {
        var arrErrors = [];
        if ($('.panel1').is(":visible")) {
            arrReferralReasons = GetPanel1Data();
            report["ReferralReasons"] = JSON.stringify(arrReferralReasons);
            if (report["ReferralReasons"].length > 0) {
                $('.panel1').hide();
                $('.panel2').fadeIn();
                if ($('.liSend').length > 0) {
                    $('.liSend, .liPrevious, .liCancel').show();
                    $('.liNext').hide();
                } else {
                    $('.liNext, .liPrevious').show();
                }
            } else {
                Alert("請填寫轉診原因");
                return false;
            }
        } else if ($('.panel2').is(":visible")) {
            arrErrors = GetPanel2Data();
            if (arrErrors.length > 0) {
                Alert(arrErrors.join("<br>"));
                return false;
            }
            $('.panel2').hide();
            $('.panel3').fadeIn();
        } else if ($('.panel3').is(":visible")) {
            arrErrors = GetPanel3Data();
            if (arrErrors.length > 0) {
                Alert(arrErrors.join("<br>"));
                return false;
            }
            $('.panel3').hide();
            $('.panel4').fadeIn();
            $('.liNext').hide();
        } else if ($('.panel4').is(":visible")) {
            console.log("Not possible");
        }
    });
    // 前一步
    $('.jPrevious').click(function (e) {
        if ($('.panel2').is(":visible")) {
            $('.panel2').hide();
            $('.panel1').fadeIn();
            $('.liSend, .liPrevious, .liCancel').hide();
            $('.liNext').show();
        } else if ($('.panel3').is(":visible")) {
            $('.panel3').hide();
            $('.panel2').fadeIn();
        } else if ($('.panel4').is(":visible")) {
            $('.panel4').hide();
            $('.panel3').fadeIn();
            $('.liNext').show();
        }
    });
    // 儲存已輸入項目
    $('.jSave').click(function (e) {

        report["ReferralReasons"] = GetPanel1Data();
        if (report["ReferralReasons"].length == 0) {
            Alert("請填寫轉診原因");
            $('.panel1, .panel2, .panel3, .panel4').hide();
            $('.panel1').fadeIn();
            return false;
        }
        var arrErrors = GetPanel2Data();
        if (arrErrors.length > 0) {
            Alert(arrErrors.join("<br>"));
            $('.panel1, .panel2, .panel3, .panel4').hide();
            $('.panel2').fadeIn();
            return false;
        }
        arrErrors = GetPanel3Data();
        if (arrErrors.length > 0) {
            Alert(arrErrors.join("<br>"));
            $('.panel1, .panel2, .panel3, .panel4').hide();
            $('.panel3').fadeIn();
            return false;
        }
        arrErrors = GetPanel4Data();
        if (arrErrors.length > 0) {
            Alert(arrErrors.join("<br>"));
            $('.panel1, .panel2, .panel3, .panel4').hide();
            $('.panel4').fadeIn();
            return false;
        }
        report.ReferralReasons = JSON.stringify(arrReferralReasons);

        var profile = {
            "Mother": mother,
            "Baby": baby,
            "Report": report,
            "Operation": operation,
            "AmbulanceVitals": arrAmbulanceVitals,
        };
        $('.progress').show();
        setTimeout(function () {
            var res = Ajax(RequestAct.Insert, RequestType.Application, JSON.stringify(profile));
            $('.progress').hide();
            setTimeout(function () {
                if (res.msg === "OK") {
                    var d = JSON.parse(res.content.trim());
                    report = d["Report"];
                    mother = d["Mother"];
                    baby = d["Baby"];
                    operation = d["Operation"];
                    arrAmbulanceVitals = d["AmbulanceVitals"];
                    if (arrAmbulanceVitals.length > 0) {
                        var $divAmbulanceVitals = $('.jInsertVital').closest('fieldset').find('.inputForm:not(".divVitalSignsTemplate")'),
                            arrAmbulanceVitalsCloned = JSON.parse(JSON.stringify(arrAmbulanceVitals)),
                            arrTagFids = $divAmbulanceVitals.map(function (_, v) { return $(v).data('key'); }).get().filter(c => c > 0),
                            arrAttrs = ["At", "Temperature", "Pulse", "Respiration", "SpO2", "BloodPressure"];
                        for (var i = 0; i < arrTagFids.length; i++) {
                            arrAmbulanceVitalsCloned = arrAmbulanceVitalsCloned.filter(function (obj) { return obj.fid !== arrTagFids[i]; });
                        }
                        if (arrAmbulanceVitalsCloned.length > 0) {
                            for (var i = 0; i < $divAmbulanceVitals.length; i++) {
                                var $divAmbulanceVital = $divAmbulanceVitals.eq(i);
                                if ($divAmbulanceVital.data('key') === 0) {
                                    for (var j = 0; j < arrAmbulanceVitalsCloned.length; j++) {
                                        var chkSum = true;
                                        $.each(arrAttrs, function (_, v) {
                                            if (arrAmbulanceVitalsCloned[j][v] !== $divAmbulanceVital.find('.Ambulance' + v).val().trim()) {
                                                chkSum = false;
                                                return false;
                                            }
                                        });
                                        if (chkSum) {
                                            var fid = arrAmbulanceVitalsCloned[j]['fid'];
                                            $divAmbulanceVital.data('key', fid);
                                            arrAmbulanceVitalsCloned = arrAmbulanceVitalsCloned.filter(function (obj) { return obj.fid !== fid; });
                                            break;
                                        }
                                    }
                                }
                            }
                        }
                    }
                } else {
                    Alert(res.content);
                }
            }, 200);
        }, 200);
    });
    // 送出轉診申請
    $('.jSend').click(function (e) {
        var arrErrors = GetPanel2Data();
        if (arrErrors.length > 0) {
            Alert(arrErrors.join("<br>"));
            return false;
        }
        var applicant = JSON.parse($('#hfUerProfile').val());
        $('.editBoard #txtAddress').val(applicant["Address"]);
        $('.editBoard #txtApplicant').val(applicant["UserName"]);
        var contactPhone = (applicant["PhoneExtent"].trim().length === 0) ? [applicant["Phone"]] : [applicant["Phone"], applicant["PhoneExtent"]];
        $('.editBoard #txtContactPhone').val(contactPhone.join('#'));
        if (applicant["MobilePhone"].trim().length > 0) {
            $('.editBoard .CellPhone').show();
            $('.editBoard #txtCellPhone').val(applicant["MobilePhone"].trim());
        } else {
            $('.editBoard .CellPhone').hide();
        }

        var indexOther = arrReferralReasons.indexOf("其他"), arrtemp = [], referralReasons = "";
        if (indexOther >= 0) {
            arrtemp = arrReferralReasons.slice(0, indexOther);
            arrtemp.push("其他：" + arrReferralReasons[arrReferralReasons.length - 1]);
            referralReasons = arrtemp.join('<br>')
        } else {
            referralReasons = arrReferralReasons.join('<br>');
        }
        $('.editBoard .ReferralReasons').html(referralReasons);
        $('.editBoard .Name').text(mother.Name);
        $('.editBoard .TID').text(mother.TID);
        $('.editBoard .MotherBirthDate').text(mother.BirthDate);
        $('.editBoard .Gender').text(baby.Gender);
        $('.editBoard .BabyBirthDate').text(baby.BirthDate + ' ' + baby.BirthTime);
        $('.editBoard').fadeIn();
    });
    // 送出轉診申請
    $('.editBoard .jSubmit').click(function (e) {
        var arrErrors = [], contactPerson = new ContactPerson();
        report.Address = $('.editBoard #txtAddress').val().trim();
        contactPerson.ContactPerson = $('.editBoard #txtApplicant').val().trim();
        contactPerson.Phone = $('.editBoard #txtContactPhone').val().trim();
        contactPerson.CellPhone = $('.editBoard #txtCellPhone').val().trim();
        if (report.Address.length === 0)
            arrErrors.push("醫院地址不能空白");
        if (contactPerson.ContactPerson.length === 0)
            arrErrors.push("聯絡人員不能空白");
        if (contactPerson.Phone.length === 0 && contactPerson.CellPhone.length === 0)
            arrErrors.push("聯絡電話與手機號碼不能均為空白");
        if ((contactPerson.CellPhone.length > 0 && contactPerson.CellPhone.length !== 10) || !IsValidCellPhone(contactPerson.CellPhone))
            arrErrors.push("手機號碼輸入有誤");

        if (arrErrors.length > 0) {
            Alert(arrErrors.join("<br>"));
            return false;
        }

        var applicant = JSON.parse($('#hfUerProfile').val());
        report.HospitalID = applicant.ParentID;
        report.Applicant = applicant.fid;
        report.ReferralReasons = JSON.stringify(arrReferralReasons);

        var profile = JSON.stringify({
            "ContactPerson": contactPerson,
            "Mother": mother,
            "Baby": baby,
            "Report": report,
        });
        var res = Ajax(RequestAct.Insert, RequestType.Application, profile);
        if (res.msg === "OK") {
            var d = JSON.parse(res.content.trim());
            report = d["Report"];
            mother = d["Mother"];
            baby = d["Baby"];
            Alert("轉診資訊已登錄！<br>高醫與救護車站將會同時收到資訊<br>請繼續填寫後續重要資料");
            $('.liSend, .liCancel').remove();
            $('.liNext, .liPrevious, .liSave').show();
            closeAllPopupForms();
        } else {
            closeAllPopupForms();
            setTimeout(function () {
                Alert(res.content);
            }, 500);
        }
    });
    // 確認收案
    $('.jConfirm').click(function (e) {
        $.confirm({
            'message': "確認收案？",
            'buttons': {
                '確定': { 'class': 'blue', 'action': function () { confirmAcceptApplication(); } },
                '取消': { 'class': 'gray', 'action': function () { return false; } }
            }
        });
    });
    // 確認出發
    $('.jAttend').click(function (e) {
        var step = $(this).data('value');
        $.confirm({
            'message': "確認要設定出發？",
            'buttons': {
                '確定': { 'class': 'blue', 'action': function () { confirmAttendApplication(step); } },
                '取消': { 'class': 'gray', 'action': function () { return false; } }
            }
        });
    });
    // 結案
    $('.jClose').click(function (e) {
        $.confirm({
            'message': "確認要設定結案？",
            'buttons': {
                '確定': { 'class': 'blue', 'action': function () { confirmCloseApplication(); } },
                '取消': { 'class': 'gray', 'action': function () { return false; } }
            }
        });
    });
    // 列印
    $('.jPrint').click(function (e) {
        var para = new RequestParameters();
        para.Fid = $(this).data('key');
        SubmitPostFormWithPara(/print_/, JSON.stringify(para), "_blank");
    });
    // 新增救護車量測生命體徵
    $('body').on("click", '.jInsertVital', function (e) {
        var $fieldset = $(this).closest('fieldset'),
            $inputForms = $fieldset.find('.inputForm:not(".divVitalSignsTemplate")'),
            $template = $fieldset.find(".divVitalSignsTemplate"),
            $newInputform = $template.clone(),
            index = $inputForms.length + 1;

        $newInputform.data('key', 0);
        $newInputform.removeClass('divVitalSignsTemplate');
        var $datetime = $newInputform.find('#txtAmbulanceAt');
        $datetime.prop('id', 'txtAmbulanceAt' + index);
        $datetime.scroller({ preset: 'datetime', theme: 'android-ics', lang: 'zh_CN', });
        $newInputform.find('#txtAmbulanceTemperature').prop('id', 'txtAmbulanceTemperature' + index);
        $newInputform.find('#txtAmbulancePulse').prop('id', 'txtAmbulancePulse' + index);
        $newInputform.find('#txtAmbulanceRespiration').prop('id', 'txtAmbulanceRespiration' + index);
        $newInputform.find('#txtAmbulanceSpO2').prop('id', 'txtAmbulanceSpO2' + index);
        $newInputform.find('#txtAmbulanceBloodPressure').prop('id', 'txtAmbulanceBloodPressure' + index);
        if ($inputForms.length === 0) {
            $newInputform.insertAfter($template).show();
        } else {
            $newInputform.insertAfter($inputForms.last()).show();
        }
    });
    // 刪除救護車量測生命體徵
    $('body').on("click", '.jDeleteVital', function (e) {
        var $div = $(this).closest('.divVitalSigns'),
            fid = parseInt($div.data('key'));

        if (fid === 0) {
            $div.remove();
            return false;
        }
        $.confirm({
            'message': "確認刪除救護車量測生命體徵？",
            'buttons': {
                '確定': { 'class': 'blue', 'action': function () { $div.remove(); } },
                '取消': { 'class': 'gray', 'action': function () { return false; } }
            }
        });
    });
    // 清空救護車量測生命體徵
    $('body').on("click", '.jEmptyVital', function (e) {
        var $div = $(this).closest('.divVitalSigns');
        $div.find('.AmbulanceAt').val('');
        $div.find('.AmbulanceTemperature').val('');
        $div.find('.AmbulancePulse').val('');
        $div.find('.AmbulanceRespiration').val('');
        $div.find('.AmbulanceSpO2').val('');
        $div.find('.AmbulanceBloodPressure').val('');
    });
    // 轉入治療單位
    $('body').on("change", '#ddlTherapyUnit', function (e) {
        if ($(this).val() === "其他") {
            $('.divTherapyUnitOther').slideDown();
        } else {
            if ($('.divTherapyUnitOther').is(":visible")) {
                $('.divTherapyUnitOther').slideUp();
            }
        }
    });
    
}

function initializeComponents() {

    //function setStyle() {
    //    SetupLeftBar();
    //    $("#container").slimScroll({
    //        height: ($('#wrapper').height() - 5) + "px",
    //        size: "10px",
    //        color: "#9ea5ab",
    //    });
    //}
    //$(window).resize(function () { setStyle(); });
    //setStyle();

    //$("#txtContactPhone").inputmask({
    //    mask: ["(09)-999-9999"],
    //    greedy: false,
    //    definitions: {
    //        '*': {
    //            validator: "9",
    //            cardinality: 1
    //        }
    //    },
    //    clearIncomplete: true
    //});

    $("#txtCellPhone").inputmask({
        mask: ["0999-999-999"],
        greedy: false,
        definitions: {
            '*': {
                validator: "9",
                cardinality: 1
            }
        },
        clearIncomplete: true
    });
}

/** application */
var application = (function () {
    var that = {};
    that.init = function () {

        initializeComponents();

        mother = new Mother();
        baby = new Baby();
        operation = new Operation();
        report = new Report();
        arrAmbulanceVitals = [];

        if ($('#hfTemp').val().trim().length > 0) {
            try {
                var profile = JSON.parse($('#hfTemp').val().trim());
                report = profile["Report"];
                mother = profile["Mother"];
                baby = profile["Baby"];
                operation = profile["Operation"];
                if ($.isEmptyObject(operation)) {
                    operation = new Operation();
                }
                arrAmbulanceVitals = profile["AmbulanceVitals"];
                if (arrAmbulanceVitals.length === 0) {
                    arrAmbulanceVitals = [];
                }
                arrReferralReasons = JSON.parse(report["ReferralReasons"]);
            } catch (e) {
                console.log(e);
            }
            $('.liSave').show();
            LoadApplicationData();
        }

        LoadSelectClickEvents();
        LoadButtonClickEvents();
    };
    return that;
})();