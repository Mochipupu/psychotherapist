﻿/**
 * 回傳錯誤碼意義
 * @param {any} error
 */
function GetErrorCode(error) {
    var chkError = error.toLowerCase();
    switch (chkError) {
        case "err110":
            return "系統忙碌中，請稍後再試一次";
        case "err120":
            return "參數錯誤";
        case "err130":
            return "網址有誤";
        case "err140":
            return "過久未有動作，系統基於保護已自動登出<br>請重新登入再試一次";
        case "err150":
            return "您並未授權執行此項作業";
        case "err200":
            return "歡迎登入<br>AI療心實驗室";
        case "err210":
            return "請先登入";
        case "err220":
            return "目前未開放註冊";
        case "err230":
            return "帳號或密碼不能空白";
        case "err240":
            return "帳號或密碼有誤";
        case "err250":
            return "請管理員設定部門後<br>再重新登入系統";
        case "err260":
            return "您的帳號已關閉";
        case "err270":
            return "您的帳號在別的裝置登入<br>基於安全性考量，系統已將您登出";

        case "err310":
            return "查無請求的資料";
        case "err315":
            return "如欲刪除此標籤<br>請從標注作業中<br>將使用此標籤之標注移除";
        case "err320":
            return "尚有資料未填寫";
        case "err330":
            return "資料已存在";
        case "err332":
            return "不允許新增資料匣";
        case "err333":
            return "不允許修改檔案名稱";
        case "err334":
            return "資料輸入有誤";
        case "err335":
            return "資料並未變更";
        case "err340":
            return "資料新增成功";
        case "err350":
            return "資料刪除成功";
        case "err360":
            return "資料修改成功";
        case "err370":
            return "資料排序成功";
        case "err380":
            return "資料設定成功";
        default:
            return (chkError.startsWith("err^")) ? error.split('^')[1] : error;//"Client端尚未建置錯誤碼";
    }
}