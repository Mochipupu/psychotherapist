﻿//顯示訊息 或且 導覽
var dialogTitle = 'AI療心實驗室';
var dialogDefaultWidth = 400;
var dialogDefaultTop = "20%";
var isKeepNonClosed = false;

function Alert(msg) {
    $.confirm({
        'title': dialogTitle,
        'message': (msg.startsWith('err')) ? GetErrorCode(msg) : msg,
        'buttons': { '確定': { 'class': 'blue', 'action': function () { } } },
    });
}

function AlertBack(msg) {
    $.confirm({
        'title': dialogTitle,
        'message': (msg.startsWith('err')) ? GetErrorCode(msg) : msg,
        'buttons': { '確定': { 'class': 'blue', 'action': function () { $('.jBack').trigger('click'); } } },
    });
}
/**
 * 顯示訊息並透過 Get 方式導引網頁
 * @param {any} msg 訊息
 * @param {any} url 導引網址
 */
function AlertGet(msg, url) {
    $.confirm({
        'title': dialogTitle,
        'message': (msg.indexOf('err') >= 0) ? GetErrorCode(msg) : msg,
        'buttons': { '確定': { 'class': 'blue', 'action': function () { location.href = url; } } },
    });
}
/**
 * 顯示訊息並透過 Post 方式導引網頁
 * @param {any} msg 訊息
 * @param {any} content 要傳遞的參數
 */
function AlertPost(msg, content) {
    $.confirm({
        'title': dialogTitle,
        'message': (msg.indexOf('err') >= 0) ? GetErrorCode(msg) : msg,
        'buttons': { '確定': { 'class': 'blue', 'action': function () { var form = $(content); $('body').append(form); form.submit(); } } },
    });
}

/**
 * 顯示訊息並關閉
 * @param {any} msg 訊息
 */
function AlertClose(msg) {
    msg = (msg.indexOf('err') >= 0) ? GetErrorCode(msg) : msg;
    $.confirm({
        'title': dialogTitle,
        'message': msg,
        'buttons': { '確定': { 'class': 'blue', 'action': function () { window.close(); } } },
    });
}
/**
 * 顯示訊息並更新網頁
 * @param {any} msg 訊息
 */
function AlertRefresh(msg) {
    $.confirm({
        'message': msg,
        'buttons': {
            '確定': { 'class': 'blue', 'action': function () { SubmitPostFormWithPara('', JSON.stringify(GetRequestParameters()), "_self"); } } },
    });
}
/**
 * 關閉其他視窗後顯示訊息
 * @param {any} msg 訊息
 */
function CloseAlert(msg) {
    closeAllPopupForms();
    $('.dm-confirmOverlay').remove();
    setTimeout(function () {
        Alert(msg);
    }, 500);
}
/**
 * 確認後透過 Get 導引網頁
 * @param {any} msg 訊息
 * @param {any} url 導引網址
 */
function ConfirmGet(msg, url) {
    $.confirm({
        'message': msg,
        'buttons': {
            '確定': { 'class': 'blue', 'action': function () { window.location = url; } },
            '取消': { 'class': 'gray', 'action': function () { } } },
    });
}
/**
 * 確認postback動作
 * @param {any} msg 訊息
 * @param {any} postBackName PostBack 的名字
 * @param {any} para 參數
 * @param {any} needGetTime 是否需要取得作業時間
 */
function ConfirmPostBack(msg, postBackName, para, needGetTime) {
    if (para === undefined)
        para = '';
    if (needGetTime !== undefined) {
        if (needGetTime) {
            $.confirm({
                'message': msg,
                'buttons': {
                    '確定': { 'class': 'blue', 'action': function () { GetTimeData(); __doPostBack(postBackName, para); } },
                    '取消': { 'class': 'gray', 'action': function () { return false; } }
                }
            });
        }
    }
    $.confirm({
        'message': msg,
        'buttons': {
            '確定': { 'class': 'blue', 'action': function () { __doPostBack(postBackName, para); } },
            '取消': { 'class': 'gray', 'action': function () { return false; } }
        }
    });
}

/** msgbox */
(function ($) {
    $.Message = function (msg, isAutoOut, seconds) {
        // msg 訊息內容；isAutoOut 是否設定時間消失；seconds 消失的時間(毫秒)
        if ($('.dm-msgbox').length > 0)
            return false;
        if (msg.startsWith('err'))
            msg = GetErrorCode(msg);
        isAutoOut = (isAutoOut === undefined) ? false : true;
        seconds = (seconds === undefined) ? 2000 : seconds;
        var $msgbox = $(["<div class='dm-dialogOverlay'><div class='dm-msgbox'>", msg, "</div></div>"].join(''));
        $msgbox.hide().appendTo('body').fadeIn();

        $('.dm-msgbox').css({ 'position': 'fixed', 'left': (($(window).outerWidth() - $('.dm-msgbox').outerWidth()) / 2 + 'px'), 'top': '40%' });

        SetScreenFreeze();
        if (isAutoOut) {
            setTimeout(function () {
                closeMessage();
            }, seconds);
        }

        $('body').on('click', '.dm-msgbox', function () {
            closeMessage();
        });

        $('body').on('click', '.dm-dialogOverlay', function () {
            closeMessage();
        });
    }

    $.Message.hide = function () {
        closeMessage();
    }
})(jQuery);
/** dialog */
(function ($) {
    $.dialog1 = function (params) {
        if ($('.dm-dialog').length)
            return false;
        if ($(window).width() <= dialogDefaultWidth) {
            $.iOS(params);
            return false;
        }
        params = setDefaultParams(params);
        params.overlay = "dm-dialogOverlay";
        params.box = 'dm-dialogBox';
        params.content = 'dm-dialogContent';
        params.button = 'dm-dialogButtons';
        constructPopforms(params);
    }
})(jQuery);

/**
 * 統一建構跳出選單
 * @param {any} params 參數值
 */
function constructPopforms(params) {

    var btnTags = '';
    if (params.button !== '') {
        $.each(params.buttons, function (name, obj) {
            btnTags += (params.button === 'dm-iosBox') ?
                '<a href="javascript:void(0)">' + name + '</a>' :
                '<a href="javascript:void(0)" class="' + obj['class'] + '">' + name + '<span></span></a>';
            if (!obj.action)
                obj.action = function () { };
        });
    }
    
    var markup = [
        "<div class='", params.overlay, "'><div class='", params.box, "'><h1>", params.title, "</h1>",
        "<div class='", params.content, "'>", params.message, "</div>"
    ].join('');
    
    if (params.button !== '') {
        markup += ["<div class='", params.button, "'>", btnTags, "</div></div></div>"].join('');
    }

    var $markup = $(markup);
    $markup.hide().appendTo('body');
    if (params.button !== 'dm-iosButtons') {
        SetPopupFormSizePosition($('.' + params.box), params.width, params.top);
    }

    var $buttons = new Array();
    if (params.button !== '') {
        $buttons = $('.' + params.button).find('a');
        if (params.button === 'dm-iosButtons') {
            $('.dm-iosBox').css({ 'left': (($(window).outerWidth() - 300) / 2) + 'px' });
            if ($buttons.length === 1)
                $('.dm-iosButtons a').css({ 'width': '100%' });
            if ($buttons.length === 3)
                $buttons.css({ 'max-width': '33%' });
        }
    }
    $markup.fadeIn();

    if (params.button !== '') {
        var i = 0;
        $.each(params.buttons, function (name, obj) {
            $buttons.eq(i++).click(function () {
                obj.action();
                closeDialogs();
                return false;
            });
        });
        $('.' + params.button).find('a').last().setfocus();
    }
    SetScreenFreeze();
}

/** $.confirm */
(function ($) {
    $.confirm = function (params) {
        if ($('.dm-confirmBox').length > 0) {
            $(".dm-confirmOverlay").fadeOut(function () {
                $(".dm-confirmOverlay").remove();
            });
        }

        if ($(window).width() <= dialogDefaultWidth) {
            $.iOS(params);
            return false;
        }
        params = setDefaultParams(params);

        params.overlay = "dm-confirmOverlay";
        if (params.keepAlive === 1)
            params.overlay += " keep";
        params.box = 'dm-confirmBox';
        params.content = 'dm-confirmContent';
        params.button = 'dm-confirmButtons';
        constructPopforms(params);
    }
})(jQuery);
/** $.iOS */
(function ($) {
    $.iOS = function (params) {
        if ($('.dm-iosBox').length)
            return false;

        params = setDefaultParams(params);
        params.overlay = "dm-dialogOverlay";
        params.box = 'dm-iosBox';
        params.content = 'dm-iosContent';
        params.button = 'dm-iosButtons';
        constructPopforms(params);
    }
})(jQuery);
/** $.popForm */
(function ($) {
    $.popform = function (params) {
        if ($('.dm-popformOverlay').length)
            return false;

        params = setDefaultParams(params);
        params.overlay = "dm-popformOverlay";
        params.box = 'dm-dialogBox';
        params.content = 'dm-dialogContent';
        params.button = '';
        constructPopforms(params);
    }
})(jQuery);

/** 關閉 Message */
function closeMessage() {
    $('.dm-dialogOverlay').not('.keep').fadeOut(function () {
        $(this).remove();
    });
    if (($('.dm-dialogBox').length + $('.dm-confirmBox').length + $('.dm-iosBox').length) === 0) {
        SetScreenDefreeze();
    }
}
/** 關閉 Dialog */
function closeDialogs() {
    if (!isKeepNonClosed) {
        var $overlayColse = $('.dm-dialogOverlay:visible:not(".keep"), .dm-confirmOverlay:visible:not(".keep"), .dm-popformOverlay:visible:not(".keep")');
        var $overlayKeep = $('.dm-dialogOverlay:visible.keep, .dm-confirmOverlay:visible.keep, .dm-popformOverlay:visible.keep');
        $overlayColse.fadeOut(function () {
            $overlayColse.remove();
        });
        if ($overlayKeep.length === 0)
            SetScreenDefreeze();
    }
    isKeepNonClosed = false;
}
/** 關閉所有存在的 popupForm */
function closeAllPopupForms() {
    $('.dm-dialogOverlay').hide();
    SetScreenDefreeze();
}

/**
 * 統一設定所有類型的 dialog 的大小與位置
 * @param {any} $msgbox 訊息內容
 * @param {any} width 數字不用 px
 * @param {any} top 文字要加 px
 * @param {any} height 文字要加 px
 */
function SetPopupFormSizePosition($msgbox, width, top, height) {
    if (width === undefined) width = dialogDefaultWidth;
    if (top === undefined) top = dialogDefaultTop;
    if (height === undefined) height = "auto";

    var winWidth = $(window).width();
    var winHeight = $(window).height();
    $msgbox.css({ "position": "fixed" });

    var $content = $msgbox.find($('.dm-dialogContent, .dm-confirmContent')),
        $btnBar = $msgbox.find($('.dm-dialogButtons, .dm-confirmButtons, .functionToolBar')),
        $h1 = $msgbox.find('h1'), contentHeight;
    if ((winWidth <= width) || (winHeight < 400)) {
        contentHeight = winHeight - $h1.outerHeight() - parseFloat($h1.css('line-height')) - $btnBar.outerHeight();
        $content.css({
            'height': contentHeight + 'px',
            'max-height': contentHeight + 'px'
        });
        $msgbox.css({
            "height": $(window).height() + "px",
            "width": winWidth + "px",
            "left": "0px",
            "top": "0px"
        });
    } else {
        if (height !== 'auto') {
            contentHeight = parseFloat(height) - $h1.outerHeight() - parseFloat($h1.css('line-height')) - $btnBar.outerHeight();
            $content.css({
                'height': contentHeight + 'px',
                'max-height': contentHeight + 'px'
            });
            $msgbox.css({
                "height": height,
                "width": width + "px",
                "left": (winWidth - width) / 2 + "px",
                "top": top
            });
        } else {
            $content.css({
                'height': '',
                'max-height': ''
            });
            $msgbox.css({
                "height": "auto",
                "width": width + "px",
                "left": (winWidth - width) / 2 + "px",
                "top": top
            });
        }
        $msgbox.draggable({
            handle: 'h1',
        });
    }
}

/**
 * 檢查並給定預設的 參數
 * @param {any} params 參數
 * @returns {any} 確認過的 params 參數
 */
function setDefaultParams(params) {

    if (params.title === undefined || params.title.trim().length === 0)
        params.title = dialogTitle;

    if (params.width === undefined)
        params.width = dialogDefaultWidth;

    if (params.top === undefined)
        params.top = dialogDefaultTop;

    return params;
}