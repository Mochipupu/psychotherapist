﻿/** ucPaginator */
var ucPaginator = (function () {
    var that = {};
    that.init = function () {

        var isQuery = ($('.txtQuery').length > 0);

        function setPage(requestPageIndex) {
            var para = GetRequestParameters();
            para.PageIndex = requestPageIndex;
            para.Act = RequestAct.Select;
            if (isQuery)
                para.Keyword = $('.txtQuery').val().trim();
            $.Message("資料載入中請稍後", 1000);
            setTimeout(function () {
                SubmitPostFormWithPara('', JSON.stringify(para), "_self");
            }, 1000);
        }

        $('body').on('click', '.firstPage', function (e) {
            setPage(parseInt($(this).data('value')));
        });
        $('body').on('click', '.lastPage', function (e) {
            setPage(parseInt($(this).data('value')));
        });
        $('body').on('click', '.prevPage', function (e) {
            setPage(parseInt($(this).data('value')));
        });
        $('body').on('click', '.nextPage', function (e) {
            setPage(parseInt($(this).data('value')));
        });
        $('body').on('click', '.pageNumber', function (e) {
            if (!$(this).hasClass('active'))
                setPage(parseInt($(this).data('value')));
        });
    };
    return that;
})();