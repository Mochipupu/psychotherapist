﻿var sArray = new Array();

//客製化下拉選單物件(
function SelectObject(bindID, thisID, thisShow, message, options, index, isAllowInput) {
    //欲新增元件 ID (即 選單 ID)，注意並無 #
    // 是否允許輸入方式
    this.IsAllowInput = (typeof (isAllowInput) === 'undefined') ? false : true;

    this.ThisID = thisID;
    //綁定物件 ID，注意並無 #
    this.BindID = bindID;
    //是否由此處顯示？
    this.ThisShow = (typeof (thisShow) === 'undefined') ? false : thisShow;
    //搜尋無結果時所顯示的訊息
    this.Message = (typeof (message) !== 'undefined') ? message : '無搜尋結果！';
    //選單
    this.Options = (typeof (options) !== 'undefined') ? options : '';
    //透過鍵盤上下移動的目前 index
    this.Index = (typeof (index) !== 'undefined') ? index : 0;
}
//客製化下拉選單
(function ($) {
    //obj 為 SelectObject 物件
    $.customSelect = function (obj) {

        // 儲存選單內的 data value，asp.net code behind 呼叫，名稱為 "hf" + obj.BindID
        //$("<input type='hidden' id='hf" + obj.BindID + "' namd='hf" + obj.BindID + "'/>").insertAfter('#' + obj.BindID);
        var markup =
            "<div id='" + obj.ThisID + "' class='dm-selectContainer'>" +
            "<div class='dm-selectBody'>" +
            "<div class='searchContainer'>" +
            "<div><input class='jselectTxt searchTxt' type='text' tabindex='0' autocomplete='off' autocorrect='off' autocapitalize='off' spellcheck='false' role='textbox'></div>" +
            "<div><a class='aClose' style='display:block' href='javascript:closeSelector(\"" + obj.BindID + "\")' title'取消選擇'>取消選擇</a></div>" +
            "</div>" +
            "<span class='optionContainer'>" +
            "<ul class='optionBody'>" +
            "<li class='option' data-name='請選擇' data-value='-1'>請選擇</li>" +
            obj.Options +
            "</ul>" +
            "</span>" +
            "<div class='optionMessage displaynone'>" + obj.Message + "</div>" +
            "</div>" +
            "</div>";
        $(markup).hide().appendTo('body');
        //先插入 appenTo

        if (isMobile()) {
            $('#' + obj.ThisID + ' li').css({ 'padding': '15px', 'border-bottom': '1px dotted silver' });
        } else {
            $('#' + obj.ThisID + ' li i').css({ 'display': 'none' });
        }

        if ($('#' + obj.BindID).val().trim().length > 0) {
            var val = $('#' + obj.BindID).val().trim();
            var i = 0;
            $('#' + obj.ThisID + ' li').each(function (e) {
                if ($(this).data('name') === val) {
                    $(this).addClass('active');
                    obj.Index = i;
                    if ($("#hf" + obj.BindID).length > 0)
                        $("#hf" + obj.BindID).val($(this).data('value'));
                    return false;
                }
                i++;
            });
        }

        $('body').on('click', '#' + obj.BindID, function () {
            if (obj.ThisShow)
                $.customSelect.show(obj.BindID);
        });

        $('body').on('keyup', '#' + obj.ThisID + ' .jselectTxt', function (e) {
            $('#' + obj.ThisID + ' .optionMessage').hide();
            var value = $(this).val().toLowerCase();
            if (value.length === 0) {
                $('#' + obj.ThisID + ' li').each(function () {
                    $(this).show();
                });
            } else {
                $('#' + obj.ThisID + ' li').each(function () {
                    $(this).toggle(($(this).data('name').toLowerCase().indexOf(value) >= 0));
                });
                if ($('#' + obj.ThisID + ' li:visible').length === 0)
                    $('#' + obj.ThisID + ' .optionMessage').show();
            }
        }).on('keydown', '#' + obj.ThisID + ' .jselectTxt', function (e) {
            for (var i = 0; i < sArray.length; i++) {
                if (sArray[i].ThisID == $(this).parents('.dm-selectContainer').prop('id')) {
                    var index = sArray[i].Index;
                    switch (e.which) {
                        case 13: // Enter
                            if (obj.IsAllowInput) {
                                var inputWords = $(this).val().trim();
                                setInputAsValue(inputWords);
                                $(this).val('');
                                $('#' + obj.ThisID + ' li').show();
                                $('#' + obj.ThisID + ' .optionMessage').hide();
                            } else
                                setSelectedAsValue($('#' + obj.ThisID + ' li:visible').eq(index));
                            break;
                        case 38: // up
                            if ((--index) < 0)
                                index = 0;
                            break;
                        case 40: // down
                            if ((++index) == $('#' + obj.ThisID + ' li:visible').length) {
                                index = $('#' + obj.ThisID + ' li:visible').length - 1;
                            }
                            break;
                    }

                    $('#' + obj.ThisID + ' .optionBody').scrollTop($('#' + obj.ThisID + ' li').outerHeight() * index);
                    if (sArray[i].Index != index) {
                        $('#' + obj.ThisID + ' li:visible').eq(sArray[i].Index).removeClass("current");
                        $('#' + obj.ThisID + ' li:visible').eq(index).addClass("current");
                        sArray[i].Index = index;
                    }
                    //e.preventDefault(); // prevent the default action (scroll / move caret)
                    break;
                }
            }
        }).on('blur', '#' + obj.ThisID + ' .jselectTxt', function () {
            $('#' + obj.ThisID).hide();
            closeSelector(obj.BindID);
        });

        $('body').on('mousedown', '#' + obj.ThisID + ' li', function () {
            setSelectedAsValue($(this));
        });


        function setInputAsValue(inputWords) {
            $('#' + obj.BindID).val(inputWords);
            if ($("#hf" + obj.BindID).length > 0)
                $("#hf" + obj.BindID).val(inputWords);

            $('#' + obj.ThisID + ' li').removeClass('active');
            $('#' + obj.ThisID).hide();
            $('#' + obj.BindID).trigger("change");
            closeSelector(obj.BindID);
        }

        function setSelectedAsValue($this) {
            // set value
            $('#' + obj.BindID).val($this.data('name'));
            if ($("#hf" + obj.BindID).length > 0)
                $("#hf" + obj.BindID).val($this.data('value'));
            $('#' + obj.ThisID + ' li').removeClass('active');
            $this.addClass('active');
            $('#' + obj.ThisID).hide();
            $('#' + obj.BindID).trigger("change");
            closeSelector(obj.BindID);
        }

        sArray.push(obj);
    }

    //顯示
    $.customSelect.show = function (BindID) {
        for (var i = 0; i < sArray.length; i++) {
            if (sArray[i].BindID == BindID) {

                var ThisID = sArray[i].ThisID;
                var $inputText = $('#' + ThisID + ' .searchContainer .searchTxt');

                if (isMobile()) {
                    $('#' + ThisID).css({ 'position': 'fixed', 'top': '0', 'left': '0', 'width': '100%', 'height': $(window).height(), 'background': 'rgba(0, 0, 0, 0.6)', 'padding': '10px' });
                    if (sArray[i].IsAllowInput) {
                        $inputText.show();
                        $inputText.css('margin-bottom', '10px');
                    }
                    $('#' + ThisID + ' .searchContainer .aClose').css('display', 'block');
                    $('#' + ThisID + ' .optionContainer .optionBody').css('max-height', $(window).height() - 70 + 'px');
                    $('#' + ThisID + ' li .fa-circle').show();
                    $('#' + ThisID + ' li .fa-dot-circle').hide();
                    $('#' + ThisID + ' li.active .fa-circle').hide();
                    $('#' + ThisID + ' li.active .fa-dot-circle').show();
                    $('#' + ThisID + ' .jselectTxt').val('');
                    $('#' + ThisID + ' .jselectTxt').setfocus();
                    SetScreenFreeze();
                    $('#' + ThisID).show();
                } else {
                    $('#' + ThisID).css({ 'position': 'absolute', 'top': $('#' + BindID).offset().top + $('#' + BindID).outerHeight(), 'left': $('#' + BindID).offset().left, 'width': $('#' + BindID).outerWidth() });
                    $inputText.show();
                    $inputText.css('margin-bottom', '0px');
                    $('#' + ThisID + ' .searchContainer .aClose').css('display', 'none');
                    $('#' + ThisID).show();
                    $('#' + BindID).blur();
                    $('#' + ThisID + ' .jselectTxt').setfocus();
                }
                break;
            }
        }
    }

    //隱藏
    $.customSelect.hide = function (BindID) {
        closeSelector(BindID);
    }

    //更新選單
    $.customSelect.update = function (params) {
        for (var i = 0; i < sArray.length; i++) {
            if (sArray[i].BindID == params.BindID) {
                $('#' + sArray[i].ThisID + ' li').remove();
                $('#' + sArray[i].ThisID + ' .optionBody').append(params.options);
                break;
            }
        }
    }
})(jQuery);

//關閉 Message
function closeSelector(BindID) {
    for (var i = 0; i < sArray.length; i++) {
        if (sArray[i].BindID == BindID) {
            $('#' + sArray[i].ThisID).hide();
            break;
        }
    }
    SetScreenDefreeze();
}

/**
 * 初始化客製化選單
 * @param {string} $options 需要於後台設定 $options 的格式為序列化的 List<KeyValue>，其中 Key = text 的 id, Value 為 options
 * @param {object} $bindObjs 欲綁定的物件陣列
 * @param {object} isAllowInput 是否允許自行輸入
 */
function InitializeCustomSelectItems($options, $bindObjs, isAllowInput) {

    var arrOptions = JSON.parse($options.trim());
    $bindObjs.each(function (e) {
        var txtID = $(this).prop('id');
        if ($('.j' + txtID).length >= 1)
            return;
        $.customSelect(new SelectObject(txtID, 'j' + txtID, true, '無結果', arrOptions.find(c => c.Key === txtID).Value, 0, isAllowInput));
    });
}

/**
 * 更新某物件的客製化選單
 * @param {string} $options 需要於後台設定 $options 的格式為序列化的 List<KeyValue>，其中 Key = text 的 id, Value 為 options
 * @param {string} newOptions 某物件欲更新後的清單
 * @param {object} $bindObj 欲綁定的物件陣列
 * @returns {string} 置換過更新的newOptions的 $options 序列化字串
 */
function UpdatedCustomSelectItems($options, newOptions, $bindObj) {
    // 更新綁定內容
    var id = $bindObj.prop('id');
    $.customSelect.update({ 'BindID': id, 'options': newOptions });
    // 更新 $options
    var arrOptions = JSON.parse($options.trim()).filter(function (el) {
        return el.Key !== id;
    });
    arrOptions.push(new KeyValue(id, newOptions));
    return JSON.stringify(arrOptions);
}