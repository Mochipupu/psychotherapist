﻿/** 標題選單 */
var headmenu = (function () {
    var that = {};
    that.init = function () {

        function logout() {
            var res = Ajax(RequestAct.Select, RequestType.Logout, "");
            if (res.msg === "OK") {
                location.href = '/login';
            } else {
                setTimeout(function () {
                    Alert(res.content);
                }, 500);
            }
        }

        $('.jHelper').click(function (e) {
            $('.helperList').fadeIn();
            SetScreenFreeze();
            if (isMobile() && $('.leftbarToggle').is(":visible"))
                $('.leftbarToggle').hide();
        });
        $('.jLogout').click(function (e) {
            var res = {};
            $.confirm({
                'message': '確定要登出系統？',
                'buttons': {
                    '確定': { 'class': 'blue', 'action': function () { logout(); } },
                    '取消': { 'class': 'gray', 'action': function () { return false; } }
                }
            });
        });
    };
    return that;
})();

//選單
var ucLeftBar = (function () {
    var that = {};
    that.init = function () {

        $('#header .leftbar-Logo').remove();
        $('.dm-contentPage').removeAttr("style");

        SetupLeftBar();
        $(window).resize(function (e) { SetupLeftBar(); });

        $('.dm-submenu a').each(function (e) {
            if ($(this).hasClass('active')) {
                $(this).closest('.dm-submenu').slideDown();
                return false;
            }
        });

        $('#sidebar-menu a').click(function (e) {
            var typeCode = $(this).data('type');
            if (typeCode.length > 0) {
                var paras = new RequestParameters();
                paras.TypeCode = typeCode;
                SubmitPostFormWithPara('', JSON.stringify(paras), "_self");
            }
            var $icon = $(this).find('i.fa-caret-right');
            if ($icon.length === 1) {
                $('#sidebar-menu > ul > li > a').removeClass('active');
                $('#sidebar-menu .dm-submenu').slideUp();
                $('#sidebar-menu i.fa-caret-down').removeClass('fa-caret-down').addClass('fa-caret-right');
                $icon.removeClass('fa-caret-right').addClass('fa-caret-down');
                $(this).next('.dm-submenu').slideDown();
                $(this).addClass('active');
            } else {
                $(this).next('.dm-submenu').slideUp();
                $(this).find('i.fa-caret-down').removeClass('fa-caret-down').addClass('fa-caret-right');
                $(this).removeClass('active');
            }
        });

        $('body').on('click', '.leftbarToggle', function (e) {
            $(this).closest('div').toggleClass('close');
            $(this).toggleClass('active');
        });

        $('.mainPage .iconItem').click(function (e) {
            var typeCode = $(this).find('.iconContainer').data('type');
            var paras = GetRequestParameters();
            paras.TypeCode = typeCode;
            SubmitPostFormWithPara('', JSON.stringify(paras), "_self");
        });
    };
    return that;
})();