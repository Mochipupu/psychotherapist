﻿var gMOUSEUP = false, gMOUSEDOWN = false, isMouseSelecting = true;

/** 
 *  設定滑鼠選取的範圍$region，其中的物件清單項目 (標記為 targetClass)
 *  則可以 add remove class'active'進行 被選取 或取消
 */
var mouseSelection = (function () {
    var that = {};
    that.init = function ($region, targetClass, fixX, fixY) {
        // Click coordinates
        var x1, x2, y1, y2,
            selection = false,
            $selection = $("#mouseSelection");
        if ($selection.length === 0) {
            $selection = $("<div id='mouseSelection'></div>");
            $selection.appendTo($region);
            console.log("$selection.length = " + $selection.length);
        }
        console.log('mouseSelection init');

        $selection.css({
            position: 'absolute',
            left: '0px',
            top: '0px',
            width: '0px',
            height: '0px',
            border: '1px solid white',
            background: '#1B94E0',
            display: 'none',
            opacity: '0.4',
            filter: 'alpha(opacity = 40)',
            zIndex: '9999'
        });

        // Global Events if left mousebutton is pressed or nor (usability fix)
        $(document).mouseup(function () {
            gMOUSEUP = true;
            gMOUSEDOWN = false;
        });
        $(document).mousedown(function () {
            gMOUSEUP = false;
            gMOUSEDOWN = true;
        });

        // Selection frame (playground :D)
        $region.mousedown(function (e) {
            if ($(e.target).closest('ul').hasClass('fileMenu') || isMobile()) {
                selection = false;
                return false;
            }
            console.log('mouseSelection mousedown');
            if (isMouseSelecting && e.which === 1 && $(e.target).parents('.iconItem').length === 0) {
                selection = true;
                // store mouseX and mouseY
                x1 = e.pageX - fixX;
                y1 = e.pageY - fixY;
                if (!e.ctrlKey)
                    $('.' + targetClass).removeClass('active');
            }
        });

        // If selection is true (mousedown on selection frame) the mousemove 
        // event will draw the selection div
        $region.mousemove(function (e) {
            if (isMouseSelecting && e.which === 1) {
                if (selection) {
                    // Store current mouseposition
                    x2 = e.pageX - fixX;
                    y2 = e.pageY - fixY;

                    if (selection) {
                        // Calculate the div selection rectancle for positive and negative values
                        var TOP = (y1 < y2) ? y1 : y2;
                        var LEFT = (x1 < x2) ? x1 : x2;
                        var WIDTH = (x1 < x2) ? x2 - x1 : x1 - x2;
                        var HEIGHT = (y1 < y2) ? y2 - y1 : y1 - y2;

                        // Use CSS to place your selection div
                        $selection.css({
                            left: LEFT,
                            top: TOP,
                            width: WIDTH,
                            height: HEIGHT
                        });
                        $selection.show();
                        $('.' + targetClass).each(function () {
                            var p = $(this).offset();
                            // Calculate the center of every element, to save performance while calculating if the element is inside the selection rectangle
                            var xmiddle = p.left + $(this).width() / 2;
                            var ymiddle = p.top + $(this).height() / 2;
                            if (matchPos(xmiddle, ymiddle)) {
                                $(this).addClass('active');
                            } else {
                                $(this).removeClass('active');
                            }
                        });
                    }
                }
            }
        });
        // Selection complete, hide the selection div (or fade it out)
        $region.mouseup(function (e) {
            if (isMouseSelecting && e.which === 1) {
                selection = false;
                $selection.css({ 'width': '0px', 'height': '0px', 'display': 'none' });
            }
        });
        // Usability fix. If mouse leaves the selection and enters the selection frame again with mousedown
        $region.mouseenter(function (e) {
            if (isMouseSelecting && e.which === 1) {
                (gMOUSEDOWN) ? selection = true : selection = false;
            }
        });
        // Usability fix. If mouse leaves the selection and enters the selection div again with mousedown
        $region.mouseenter(function (e) {
            if (isMouseSelecting && e.which === 1) {
                (gMOUSEDOWN) ? selection = true : selection = false;
            }
        });
        // Set selection to false, to prevent further selection outside of your selection frame
        $region.mouseleave(function (e) {
            if (isMouseSelecting && e.which === 1) {
                selection = false;
            }
        });

        function matchPos(xmiddle, ymiddle) {
            var myX1, myX2, myY1, myY2;
            // If selection is done bottom up -> switch value
            if (x1 > x2) {
                myX1 = x2;
                myX2 = x1;
            } else {
                myX1 = x1;
                myX2 = x2;
            }
            if (y1 > y2) {
                myY1 = y2;
                myY2 = y1;
            } else {
                myY1 = y1;
                myY2 = y2;
            }
            // Matching
            if ((xmiddle > myX1) && (xmiddle < myX2)) {
                if ((ymiddle > myY1) && (ymiddle < myY2)) {
                    return true;
                } else {
                    return false;
                }
            } else {
                return false;
            }
        }
    };
    return that;
})();